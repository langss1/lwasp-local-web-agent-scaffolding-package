#!/usr/bin/env python3
"""P2 step 3 -- analyse the confirmatory campaign (reviewers R2-A, R2-B, R1-B).

Between-arm PAIRED analysis on matched (scenario, model, seed) units:
  base__simple_tooled   -> value of execution/verification ACCESS
  simple_tooled__full   -> value of ORCHESTRATION  (the paper's core claim, R2-A)
  base__full            -> value of the TOTAL package
Each contrast: exact McNemar (two-sided binomial on discordant pairs) + paired OSR
difference + scenario-cluster bootstrap CI. Holm correction across the two
orchestration contrasts. Dev-set K1 results are NOT pooled here (R2-B) -- they are
reported separately by the existing k1_* analysis.

Opportunity parity (R1-B): for effect classes requiring a browser-verified trace,
`base` has no opportunity to be credited; those classes are flagged so the headline
contrast is simple_tooled->full (equal evidence opportunity), not base->full.

Refuses to run unless every analysed report traces to the frozen prereg (freeze_sha
+ arm_hash match). status=FINAL only when all scheduled cells are present & valid.

Usage:
    python phase_code/analyze_confirmatory.py [--prereg results/prereg_confirmatory.json]
        [--runs runs]
"""
import argparse, json, math, os, random, statistics

HERE = os.path.dirname(os.path.abspath(__file__))
PREREG_DEFAULT = os.path.join("results", "prereg_confirmatory.json")
BOOT_SEED, N_BOOT = 20261124, 20000

# effect classes where crediting needs a browser-verified trace (R1-B / R2-A XSS).
BROWSER_EVIDENCE_PREFIXES = ("xss_", "js_", "open_redirect_")


def load_cell(runs_dir, rid, prereg, arm):
    rp = os.path.join(runs_dir, rid, "report.json")
    if not os.path.exists(rp):
        return None, "missing"
    try:
        rep = json.load(open(rp, encoding="utf-8"))
    except (ValueError, OSError):
        return None, "unreadable"
    if not isinstance(rep, dict):
        return None, "not_object"
    if rep.get("invalid"):
        return None, "invalid:" + str(rep.get("finish_reason", ""))
    meta = rep.get("_meta", {})
    if meta.get("freeze_sha") != prereg["freeze_sha"]:
        return None, "freeze_mismatch"
    if meta.get("arm_hash") != prereg["arm_hashes"][arm]:
        return None, "arm_hash_mismatch"
    if not isinstance(rep.get("success"), bool):
        return None, "no_success_field"
    return int(rep["success"]), "ok"


def exact_mcnemar(b, c):
    """Two-sided exact McNemar (binomial) on discordant counts b, c."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    tail = sum(math.comb(n, i) for i in range(0, k + 1)) * (0.5 ** n)
    return min(1.0, 2 * tail)


def cluster_bootstrap_ci(pairs_by_scen, key):
    """CI for the paired OSR difference (arm_t - arm_r) via scenario-cluster bootstrap."""
    scens = list(pairs_by_scen)
    if not scens:
        return None
    rng = random.Random(BOOT_SEED)
    diffs = []
    for _ in range(N_BOOT):
        r_sum = t_sum = n = 0
        for _ in scens:
            for r_v, t_v in pairs_by_scen[rng.choice(scens)]:
                r_sum += r_v; t_sum += t_v; n += 1
        if n:
            diffs.append(100.0 * (t_sum - r_sum) / n)
    diffs.sort()
    return [round(diffs[int(0.025 * len(diffs))], 2),
            round(diffs[int(0.975 * len(diffs))], 2)]


def contrast(ref, tr, cells):
    """cells: {(scen,model,seed): {arm: 0/1}}. Paired units where BOTH arms valid."""
    b = c = 0  # b: ref=1,tr=0 ; c: ref=0,tr=1
    paired = 0
    pairs_by_scen = {}
    for (scen, _m, _s), d in cells.items():
        if ref in d and tr in d:
            rv, tv = d[ref], d[tr]
            paired += 1
            pairs_by_scen.setdefault(scen, []).append((rv, tv))
            if rv == 1 and tv == 0:
                b += 1
            elif rv == 0 and tv == 1:
                c += 1
    if paired == 0:
        return {"contrast": f"{ref}__{tr}", "paired_units": 0, "note": "no paired units"}
    diff_pp = round(100.0 * (c - b) / paired, 2)  # tr advantage over ref
    return {"contrast": f"{ref}__{tr}", "paired_units": paired,
            "discordant_ref_only": b, "discordant_tr_only": c,
            "paired_osr_diff_pp": diff_pp,
            "mcnemar_p": round(exact_mcnemar(b, c), 4),
            "cluster_ci_pp": cluster_bootstrap_ci(pairs_by_scen, f"{ref}__{tr}")}


def holm(pvals):
    """Holm-Bonferroni; returns {label: adjusted_p}."""
    order = sorted(pvals.items(), key=lambda kv: kv[1])
    m = len(order)
    adj, prev = {}, 0.0
    for i, (lab, p) in enumerate(order):
        a = min(1.0, (m - i) * p)
        a = max(a, prev); prev = a
        adj[lab] = round(a, 4)
    return adj


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--prereg", default=PREREG_DEFAULT)
    ap.add_argument("--runs", default="runs")
    args = ap.parse_args()
    prereg = json.load(open(args.prereg, encoding="utf-8"))
    runs_dir = os.path.abspath(args.runs)

    cells = {}            # (scen,model,seed) -> {arm: 0/1}
    per_cell_rows = []
    invalid, missing = [], []
    osr_num = {a: 0 for a in prereg["arms"]}
    osr_den = {a: 0 for a in prereg["arms"]}

    for scen in prereg["scenarios"]:
        is_browser = scen.startswith(BROWSER_EVIDENCE_PREFIXES)
        for model in prereg["models"]:
            for seed in prereg["seeds"]:
                key = (scen, model, seed)
                for arm in prereg["arms"]:
                    rid = f"conf-{arm}-{model}-{scen}-s{seed}"
                    val, status = load_cell(runs_dir, rid, prereg, arm)
                    per_cell_rows.append({"scenario": scen, "model": model, "seed": seed,
                                          "arm": arm, "rid": rid, "status": status,
                                          "success": "" if val is None else val,
                                          "browser_evidence_class": int(is_browser)})
                    if val is None:
                        (missing if status == "missing" else invalid).append(rid)
                        continue
                    cells.setdefault(key, {})[arm] = val
                    osr_den[arm] += 1
                    osr_num[arm] += val

    contrasts = {f"{r}__{t}": contrast(r, t, cells)
                 for r, t in [("base", "simple_tooled"),
                              ("simple_tooled", "full"),
                              ("base", "full")]}
    # Holm across the two ORCHESTRATION-relevant contrasts the prereg named.
    orch_contrasts = {k: contrasts[k]["mcnemar_p"]
                      for k in ("base__simple_tooled", "simple_tooled__full")
                      if "mcnemar_p" in contrasts[k]}
    holm_adj = holm(orch_contrasts) if orch_contrasts else {}

    scheduled = prereg["scheduled_cells"]
    present_valid = sum(osr_den.values())
    is_final = (present_valid == scheduled) and not invalid

    out = {
        "status": "FINAL" if is_final else "PARTIAL",
        "freeze_sha": prereg["freeze_sha"],
        "target": prereg["target"],
        "scheduled_cells": scheduled,
        "present_valid_cells": present_valid,
        "invalid_cells": invalid,
        "missing_cells": missing,
        "osr_per_arm_pp": {a: (round(100 * osr_num[a] / osr_den[a], 2) if osr_den[a] else None)
                           for a in prereg["arms"]},
        "osr_denominator": {a: f"{osr_num[a]}/{osr_den[a]}" for a in prereg["arms"]},
        "contrasts": contrasts,
        "holm_adjusted_p_orchestration": holm_adj,
        "headline_contrast": "simple_tooled__full",
        "opportunity_parity_note": (
            "R1-B: for browser-evidence classes (xss_/js_/open_redirect_) `base` has no "
            "opportunity to be credited (HTTP-only, cannot run the verifier). The "
            "orchestration claim therefore rests on simple_tooled->full, where both arms "
            "have identical evidence opportunity. base->full is the total-package contrast "
            "and is NOT interpreted as orchestration."),
        "dev_set_note": "K1 development-set estimates are reported separately (descriptive); "
                        "not pooled with these confirmatory units (R2-B).",
    }
    if not is_final:
        out["WARNING"] = ("PARTIAL: confirmatory numbers are provisional until every "
                          "scheduled cell is present & valid. Do NOT report as confirmatory.")

    os.makedirs("results", exist_ok=True)
    json.dump(out, open("results/confirmatory_result.json", "w", encoding="utf-8"), indent=2)
    import csv
    with open("results/confirmatory_percell.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["scenario", "model", "seed", "arm", "rid",
                                           "status", "success", "browser_evidence_class"])
        w.writeheader(); w.writerows(per_cell_rows)
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
