# P3 instrumentation patch spec (reviewer R1-I)

Minimal, reversible patch to `src/orchestrator.py` on the pod. Adds per-phase
timers without changing any control flow. Guarded by `PHASE_TIMING=1`, so the
production code path is byte-identical when the env var is unset (no confound with
the headline runs).

## 1. import (top of orchestrator.py)
```python
from phase_code.phase_timer import TIMER
```

## 2. three call sites (wrap only; do not move logic)

**gen** — the model generation call (cognitive_engine.generate, ~emits the ACTION).
Around line 190 region where `{"type": "HTTP_REQUEST", ...}` is produced:
```python
with TIMER.phase("gen"):
    action = self.cognitive_engine.generate(prompt, ...)
```

**action** — the non-verify action execution (HTTP_REQUEST / RUN_TOOL path, ~979).
```python
with TIMER.phase("action"):
    observation = self._execute_action(action)   # HTTP_REQUEST / RUN_TOOL only
```
Do NOT wrap the VERIFY branch here — verify has its own bucket (the timer is
non-reentrant, but keeping them lexically separate avoids accidental nesting).

**verify** — the oracle / browser verification (VERIFY handling ~1461, browser_verifier).
```python
with TIMER.phase("verify"):
    vres = self._verify(...)   # oracle_universal / BrowserVerifier.verify_xss
```

## 3. run start / end
At the top of `run()`:
```python
TIMER.reset()
```
At the end of `run()`, after `wall_clock_s` is computed and before writing report:
```python
report.update(TIMER.dump(report["wall_clock_s"]))
```

## 4. why this answers R1-I
- `t_gen_s` vs `t_action_s` vs `t_verify_s` are now separate (reviewer asked to
  "separate model-generation time from action and verification time").
- `t_other_s = wall - gen - action - verify` makes model-loading / parse-repair /
  oracle-replay explicit instead of hidden inside "action" (Table 5 contract).
- Running the matched-stopping subset (base vs full) shows WHY base reaches 15
  iterations: base cannot trigger the verified-FINISH early stop (no verify bucket
  activity), so it spends its whole budget on gen+action; full stops once a verify
  succeeds. The explanation is the stopping contract, not reasoning quality.

## 5. verification that the patch is honest
`analyze_timing.py` asserts, per report, that
`gen + action + verify + other == wall_clock_s` (within 1%). A report that fails
this is dropped and listed, so a mis-placed timer cannot silently distort the table.
