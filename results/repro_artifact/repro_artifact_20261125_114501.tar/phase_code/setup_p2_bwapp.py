"""Set up P2 (strict confirmatory) for bWAPP on the pod. Idempotent.
 1) Patch _conf_worker.py to apply config-driven oracle markers after load_config
    (so cross-app SQLi/blind oracle fires; config-driven, not app-hardcoded).
 2) Generate config_bwapp.yaml from config.yaml (base_url/login/webroot + oracle_markers).
 3) Write reset_bwapp.sh (install.php clean reset; markers are oracle-side, not DB).
Run on pod: .venv/bin/python phase_code/setup_p2_bwapp.py"""
import os, shutil, yaml

ROOT = "/workspace/pentest-agent"
WORKER = os.path.join(ROOT, "phase_code", "_conf_worker.py")
CFG_IN = os.path.join(ROOT, "config.yaml")
CFG_OUT = os.path.join(ROOT, "config_bwapp.yaml")
RESET = os.path.join(ROOT, "eval", "reset_bwapp.sh")

MARK = "# IJIES-P2-MARKERS: config-driven oracle markers for cross-app confirmatory"
INJECT = '''    {mark}
    _om = cfg.get("oracle_markers") or {{}}
    if _om:
        from src.orchestrator import set_sqli_row_markers, set_blind_markers
        if _om.get("sqli"):
            set_sqli_row_markers(list(_om["sqli"]))
        if _om.get("blind_exists") or _om.get("blind_missing"):
            set_blind_markers(exists=_om.get("blind_exists"), missing=_om.get("blind_missing"))
'''.format(mark=MARK)

def patch_worker():
    src = open(WORKER, encoding="utf-8").read()
    if MARK in src:
        print("worker: already patched (idempotent) -> skip")
        return
    anchor = "    cfg = load_config(cfg_path)\n"
    if anchor not in src:
        raise SystemExit("worker: anchor 'cfg = load_config(cfg_path)' not found")
    shutil.copy(WORKER, WORKER + ".bak_p2markers")
    src = src.replace(anchor, anchor + INJECT, 1)
    open(WORKER, "w", encoding="utf-8").write(src)
    print("worker: patched (backup .bak_p2markers)")

def gen_config():
    cfg = yaml.safe_load(open(CFG_IN, encoding="utf-8"))
    cfg["target"]["base_url"] = "http://localhost/bWAPP"
    cfg["target"]["webroot"] = "/var/www/html/bWAPP"
    cfg["target"]["login_user"] = "bee"
    cfg["target"]["login_pass"] = "bug"
    cfg["oracle_markers"] = {
        "sqli": ['<tr height="30">'],
        "blind_exists": ["imdb.com/title/"],
        "blind_missing": ["No movies were found"],
    }
    yaml.safe_dump(cfg, open(CFG_OUT, "w", encoding="utf-8"), sort_keys=False, allow_unicode=True)
    print("config_bwapp.yaml written; base_url=%s markers=%s" % (
        cfg["target"]["base_url"], cfg["oracle_markers"]))

def write_reset():
    body = (
        "#!/usr/bin/env bash\n"
        "# Reset bWAPP to a clean snapshot per confirmatory unit (R1-E).\n"
        "# install.php drops+recreates the bWAPP DB (clears stored-XSS/injected rows).\n"
        "# Oracle markers are response-signature based (set per worker via config), not DB rows.\n"
        "set -e\n"
        "curl -s -o /dev/null \"http://127.0.0.1/bWAPP/install.php?install=yes\"\n"
        "# sanity: DB present\n"
        "mysql -u root -e 'USE bWAPP; SELECT 1;' >/dev/null 2>&1 || { echo 'bWAPP DB missing after reset' >&2; exit 1; }\n"
        "exit 0\n"
    )
    open(RESET, "w", encoding="utf-8").write(body)
    os.chmod(RESET, 0o755)
    print("reset_bwapp.sh written")

if __name__ == "__main__":
    patch_worker()
    gen_config()
    write_reset()
    print("P2 bWAPP setup DONE")
