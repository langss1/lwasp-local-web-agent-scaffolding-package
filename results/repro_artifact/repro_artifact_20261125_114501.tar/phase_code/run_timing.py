#!/usr/bin/env python3
"""P3 step 2 -- run the timing subset with instrumentation ON (reviewer R1-I).

Reuses the confirmatory worker and the FROZEN arm dicts, but on a small directed
subset (timing is not a success metric, so few seeds suffice) with PHASE_TIMING=1.
Resume-safe. Each cell runs fresh on a reset snapshot like P2.

Usage:
    python phase_code/run_timing.py --root /workspace/pentest-agent \
        --reset-cmd "bash .../reset_dvwa.sh {app}" \
        [--config phase_code/timing_config.json] [--runs runs_timing]
"""
import argparse, json, os, shutil, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
PREREG = os.path.join("results", "prereg_confirmatory.json")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--reset-cmd", required=True)
    ap.add_argument("--app", default="dvwa")
    ap.add_argument("--config", default=os.path.join(HERE, "timing_config.json"))
    ap.add_argument("--prereg", default=PREREG)
    ap.add_argument("--runs", default="runs_timing")
    ap.add_argument("--cell-timeout", type=int, default=1500)
    args = ap.parse_args()

    cfg = json.load(open(args.config, encoding="utf-8"))
    if not os.path.exists(args.prereg):
        raise SystemExit("Frozen prereg required (arm dicts come from it).")
    runs_dir = os.path.abspath(args.runs)
    os.makedirs(runs_dir, exist_ok=True)

    arms_ = cfg["arms"]
    units = [(s, m, sd) for s in cfg["scenarios"] for m in cfg["models"] for sd in cfg["seeds"]]
    env = dict(os.environ, PHASE_TIMING="1")
    done = 0
    for ui, (scen, model, seed) in enumerate(units):
        if not os.path.exists(os.path.join(runs_dir, "_reset.flag")):
            pass
        # reset snapshot per unit
        subprocess.run(args.reset_cmd.format(app=args.app, unit=f"{scen}-{model}-s{seed}"),
                       shell=True)
        for arm in arms_:
            rid = f"tim-{arm}-{model}-{scen}-s{seed}"
            rundir = os.path.join(runs_dir, rid)
            if os.path.exists(os.path.join(rundir, "report.json")):
                continue
            if os.path.isdir(rundir):
                shutil.rmtree(rundir, ignore_errors=True)
            cmd = [sys.executable, os.path.join(HERE, "_conf_worker.py"),
                   "--rid", rid, "--arm", arm, "--scenario", scen, "--model", model,
                   "--seed", str(seed), "--prereg", os.path.abspath(args.prereg),
                   "--root", args.root, "--rundir", rundir]
            try:
                subprocess.run(cmd, timeout=args.cell_timeout, env=env)
            except subprocess.TimeoutExpired:
                pass
            done += 1
        print(f"[{ui+1}/{len(units)}] timing {scen}-{model}-s{seed}")
    print(json.dumps({"cells_attempted": done, "runs_dir": runs_dir}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
