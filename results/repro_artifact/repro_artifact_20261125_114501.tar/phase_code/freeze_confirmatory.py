#!/usr/bin/env python3
"""P2 step 1 -- FREEZE the confirmatory pre-registration (reviewer R2-B).

R2-B: "Establish confirmatory evidence on targets or scenario variants chosen
BEFORE inspecting results, AFTER freezing the final package and scoring criteria."

This writes prereg_confirmatory.json and LOCKS it: the held-out scenario IDs, the
three arm component dicts (hashed), the oracle implementation (hashed), the scoring
rule, the models/seeds, and the reset/snapshot contract. A single freeze_sha over
all of it is the tamper-evident anchor. run_confirmatory.py refuses to run unless a
frozen prereg exists; analyze_confirmatory.py refuses unless the report bytes trace
back to this freeze.

Usage:
    python phase_code/freeze_confirmatory.py \
        --holdout phase_code/holdout_scenarios.txt \
        --oracle  <ROOT>/src/reasoning/oracle_universal.py \
        --target  dvwa_variant_v2 \
        [--models q25 q35] [--seeds 42 7 123]

Nothing here inspects any outcome. Run it BEFORE any confirmatory run.
"""
import argparse, hashlib, json, os, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import arms  # noqa: E402

OUT = os.path.join("results", "prereg_confirmatory.json")


def sha16_bytes(b):
    return hashlib.sha256(b).hexdigest()[:16]


def sha16_file(path):
    if not path or not os.path.exists(path):
        return None
    with open(path, "rb") as fh:
        return sha16_bytes(fh.read())


def sha16_obj(obj):
    return sha16_bytes(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--holdout", required=True,
                    help="text file: one held-out scenario ID per line (chosen BEFORE results)")
    ap.add_argument("--oracle", default=None,
                    help="path to the oracle implementation file to hash (scoring provenance)")
    ap.add_argument("--target", required=True,
                    help="confirmatory target id, e.g. a new testbed or a held-out variant")
    ap.add_argument("--models", nargs="+", default=["q25", "q35"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[42, 7, 123])
    ap.add_argument("--max-iterations", type=int, default=15,
                    help="SAME budget for every arm (matched stopping contract, R2-A/R1-I)")
    ap.add_argument("--max-wall-clock-s", type=int, default=1500)
    args = ap.parse_args()

    # Arm design must satisfy the reviewer invariants BEFORE we freeze it.
    arms.assert_invariants()

    with open(args.holdout, encoding="utf-8") as fh:
        scenarios = [ln.strip() for ln in fh if ln.strip() and not ln.startswith("#")]
    if not scenarios:
        raise SystemExit("holdout file is empty -- freeze needs the chosen scenario IDs.")
    if len(scenarios) != len(set(scenarios)):
        raise SystemExit("duplicate scenario IDs in holdout file.")

    scoring = {
        "success_rule": "objective success rate (OSR): report.success == true, credited "
                        "ONLY by the deterministic evidence oracle (verified non-FINISH "
                        "trace observation), never by the agent's own claim.",
        "validity_rule": "infrastructure errors (crash/timeout/parse) are recorded as "
                         "INVALID and excluded from OSR denominator, reported separately.",
        "opportunity_parity_note": "R1-B: base is HTTP-only and cannot run the browser "
                                    "verifier, so for browser-only effect classes it has "
                                    "no opportunity to be credited. The orchestration "
                                    "contrast of record is simple_tooled->full, where both "
                                    "arms have identical evidence opportunity.",
    }
    reset_contract = {
        "mode": "per_unit_clean_snapshot",  # reviewer R1-E
        "resets": ["app_db", "session_cookies", "security_level_cookie",
                   "persisted_content", "stored_xss_artifacts"],
        "order_policy": "interleaved: arms run back-to-back on the SAME freshly-reset "
                        "snapshot per (scenario,model,seed) unit, so no arm inherits "
                        "another arm's residue (R1-E, R2-B identical state).",
        "logged_to": "results/confirmatory_reset_log.csv",
    }

    arm_hashes = {name: sha16_obj(cfg) for name, cfg in arms.ARMS.items()}

    prereg = {
        "frozen_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "purpose": "Confirmatory evidence on a held-out target chosen before inspecting "
                   "results (reviewer R2-B). Dev-set K1 estimates are reported separately "
                   "as development-set evidence.",
        "target": args.target,
        "scenarios": scenarios,
        "n_scenarios": len(scenarios),
        "arms": list(arms.ARMS),
        "arm_component_dicts": arms.ARMS,
        "arm_hashes": arm_hashes,
        "access_axis": arms.ACCESS_COMPONENTS,
        "orchestration_axis": arms.ORCHESTRATION_COMPONENTS,
        "models": args.models,
        "seeds": args.seeds,
        "budget": {"max_iterations": args.max_iterations,
                   "max_wall_clock_s": args.max_wall_clock_s,
                   "note": "identical for every arm -- matched stopping contract (R2-A, R1-I)"},
        "scoring": scoring,
        "oracle_file": args.oracle,
        "oracle_sha16": sha16_file(args.oracle),
        "reset_contract": reset_contract,
        "scheduled_cells": len(scenarios) * len(args.models) * len(args.seeds) * len(arms.ARMS),
        "analysis_plan": {
            "paired_contrasts": ["base__simple_tooled", "simple_tooled__full", "base__full"],
            "pairing_unit": "(scenario, model, seed) -- BETWEEN-arm paired on the SAME unit",
            "test": "exact McNemar per contrast + scenario-cluster bootstrap CI",
            "multiplicity": "report all three; Holm correction across the two orchestration "
                            "contrasts (base__simple_tooled, simple_tooled__full) -- SET BY FREEZE",
            "dev_set_handling": "K1 dev-set results reported separately, descriptive only; "
                                "never pooled with confirmatory units.",
        },
    }
    prereg["freeze_sha"] = sha16_obj({k: v for k, v in prereg.items() if k != "frozen_at"})

    os.makedirs("results", exist_ok=True)
    if os.path.exists(OUT):
        raise SystemExit(f"{OUT} already exists -- a prereg is already frozen. "
                         "Delete it deliberately only if you are re-registering BEFORE any run.")
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(prereg, fh, indent=2)
    print(f"FROZEN -> {OUT}")
    print(f"  target={args.target}  n_scenarios={len(scenarios)}  "
          f"cells={prereg['scheduled_cells']}  freeze_sha={prereg['freeze_sha']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
