#!/usr/bin/env python3
"""P3 instrumentation -- per-phase wall-clock timers (reviewer R1-I).

R1-I: "separate model-generation time from action and verification time" and
"Explain why Base reaches exactly 15 iterations ... whereas Full can stop earlier".

A single process-wide accumulator the orchestrator wraps around its three call
sites. NO double-count: each wrapped region adds to exactly one bucket. The leftover
(wall - gen - action - verify) is reported as `t_other_s` (model loading, parse
repair, oracle replay, scheduling) so the four buckets + other == wall.

Activate by env var PHASE_TIMING=1 (off => zero overhead, buckets absent). The
orchestrator writes TIMER.dump() into report.json at the end of a run.

Minimal patch to src/orchestrator.py (3 sites) -- see timing_patch_spec.md:
    from phase_code.phase_timer import TIMER
    with TIMER.phase("gen"):     resp = self.cognitive_engine.generate(...)
    with TIMER.phase("action"):  obs  = self._execute_action(action)      # non-verify
    with TIMER.phase("verify"):  res  = self._verify(...)                 # oracle/browser
    report.update(TIMER.dump(wall_clock_s))   # at run end
"""
import contextlib
import os
import time

_ENABLED = os.environ.get("PHASE_TIMING") == "1"


class _Timer:
    def __init__(self):
        self.buckets = {"gen": 0.0, "action": 0.0, "verify": 0.0}
        self._depth = 0  # guard against nested double-count

    def reset(self):
        self.buckets = {"gen": 0.0, "action": 0.0, "verify": 0.0}
        self._depth = 0

    @contextlib.contextmanager
    def phase(self, name):
        if not _ENABLED or name not in self.buckets or self._depth > 0:
            # disabled, unknown bucket, or already inside a timed region
            # (prevents verify-inside-action from being counted twice)
            yield
            return
        self._depth += 1
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.buckets[name] += time.perf_counter() - t0
            self._depth -= 1

    def dump(self, wall_clock_s):
        if not _ENABLED:
            return {}
        g = round(self.buckets["gen"], 3)
        a = round(self.buckets["action"], 3)
        v = round(self.buckets["verify"], 3)
        other = round(max(0.0, (wall_clock_s or 0) - g - a - v), 3)
        return {"t_gen_s": g, "t_action_s": a, "t_verify_s": v, "t_other_s": other,
                "timing_contract": "gen/action/verify measured with a non-reentrant "
                                   "timer (no double-count); t_other_s = wall - the three "
                                   "(model load, parse repair, oracle replay, scheduling)."}


TIMER = _Timer()
