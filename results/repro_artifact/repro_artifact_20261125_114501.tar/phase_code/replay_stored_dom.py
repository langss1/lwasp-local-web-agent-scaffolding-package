#!/usr/bin/env python3
"""P4 -- stored/DOM XSS evidence verification by ISOLATED replay (reviewers R1-A, R1-E, R2-A).

Only the reflected XSS class is adjudicated so far (k1_xss_adjudicated.csv). Stored
and DOM classes (~36 cases) carry the bulk of the headline XSS gain (R2-A: 36 of 63
net additional successes concentrate in the three XSS families), so their evidence
must be adjudicated with the SAME agent-independent oracle (R1-A), on an ISOLATED
instance so no run inherits another run's stored payload (R1-E stored-XSS artifacts).

For each case this re-runs the existing BrowserVerifier.verify_xss on a fresh,
isolated target (own DB/session/storage), records the verdict + screenshot artifact,
and writes a row with the SAME schema as the reflected table. Output is explicitly
labelled "controlled replay -- separate measurement"; where original state cannot be
reconstructed, the row is marked uncertain rather than claimed equivalent to online.

Cases come from replay_config.json (populated from the stored/DOM run traces:
endpoint/param/payload/method/extra_params + provenance arm/model/seed/run_id).

Usage (on pod, ISOLATED instance up):
    python phase_code/replay_stored_dom.py \
        --config phase_code/replay_config.json \
        --artifacts results/p4_artifacts
"""
import argparse, csv, json, os, sys, time

SCHEMA = ["arm", "model", "scenario", "seed", "credited", "n_executed",
          "screenshot", "run_id", "verified", "signal", "isolation_proof", "note"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--root", required=True, help="pentest-agent root (for src.action import)")
    ap.add_argument("--artifacts", default="results/p4_artifacts")
    ap.add_argument("--out", default="results/k1_stored_dom_adjudicated.csv")
    args = ap.parse_args()

    sys.path.insert(0, args.root)
    from src.action.browser_verifier import BrowserVerifier

    cfg = json.load(open(args.config, encoding="utf-8"))
    iso = cfg["isolation"]
    if cfg.get("mode") != "isolated_replay":
        raise SystemExit("replay_config.mode must be 'isolated_replay' for P4.")
    # Isolation must be a SEPARATE instance (own DB/session/storage), not just a
    # different port on the same backing store (reviewer R1-E).
    if not iso.get("separate_datastore"):
        raise SystemExit("isolation.separate_datastore must be true and evidenced "
                         "(own DB/session/storage), not a shared store on another port.")
    os.makedirs(args.artifacts, exist_ok=True)

    rows, credited, total = [], 0, 0
    for case in cfg["cases"]:
        total += 1
        # P4-RESET per-case
        _rs = iso.get("reset_sql")
        if _rs:
            import subprocess as _sp
            _sp.run(["mysql","-u","root","-e",_rs], capture_output=True)
        bv = BrowserVerifier(
            base_url=iso["base_url"], allowlist=iso["allowlist"],
            login_user=iso.get("login_user", ""), login_pass=iso.get("login_pass", ""),
            security_level=case.get("security_level", "low"), headless=True,
            artifacts_dir=args.artifacts, app=iso.get("app", "dvwa"))
        note, verified, signal, shot = "", False, "", ""
        try:
            res = bv.verify_xss(endpoint=case["endpoint"], param=case["param"],
                                payload=case["payload"], method=case.get("method", "GET"),
                                extra_params=case.get("extra_params") or {})
            verified = bool(res.success)
            signal = res.signal
            shot = res.screenshot_path or ""
            if not os.path.exists(shot):
                shot = ""  # a credited case MUST have a real screenshot artifact
            if verified and not shot:
                note = "verified-but-no-artifact -> downgraded to uncertain"
                verified = False
        except Exception as e:  # noqa: BLE001 -- a crash is an uncertain verdict, not a success
            note = f"replay_error:{type(e).__name__}"
        if case.get("state_reconstructable") is False and not note:
            note = "historical state not reconstructable -> uncertain, not equivalent to online"
        cred = int(verified and not note.startswith("historical"))
        credited += cred
        rows.append({
            "arm": case.get("arm", ""), "model": case.get("model", ""),
            "scenario": case["scenario"], "seed": case.get("seed", ""),
            "credited": cred, "n_executed": 1, "screenshot": shot,
            "run_id": case.get("source_run_id", ""), "verified": int(verified),
            "signal": signal, "isolation_proof": iso.get("proof", ""), "note": note,
        })
        print(f"  {case['scenario']} arm={case.get('arm')} verified={verified} shot={bool(shot)} {note}")

    with open(args.out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=SCHEMA)
        w.writeheader(); w.writerows(rows)
    summ = {"cases": total, "credited": credited, "out": args.out,
            "label": "controlled replay -- SEPARATE MEASUREMENT (not pooled with online OSR)",
            "isolation": iso.get("proof", ""),
            "opportunity_parity": "verifier access is identical across cases; base-class "
                                  "cases are marked since base (HTTP-only) could not have "
                                  "produced this browser evidence online (R1-B)."}
    json.dump(summ, open("results/p4_stored_dom_summary.json", "w", encoding="utf-8"), indent=2)
    print(json.dumps(summ, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
