#!/usr/bin/env python3
"""Confirmatory single-cell worker: run ONE (arm, scenario, model, seed) FRESH.

Invoked as a subprocess by run_confirmatory.py so a hard crash (ReadTimeout,
segfault, chromium) kills only this cell. Uses the FROZEN arm component dict from
prereg_confirmatory.json -- never a re-derived one -- so the run provenance traces
to the freeze (reviewer R2-B). Writes runs/<rid>/report.json.

Usage (internal):
    python phase_code/_conf_worker.py --rid <rid> --arm <arm> --scenario <sid>
        --model <ollama_tag> --seed <int> --prereg results/prereg_confirmatory.json
        --root <PENTEST_AGENT_ROOT> --rundir <abs runs/<rid>>
"""
import argparse, json, os, sys, yaml


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rid", required=True)
    ap.add_argument("--arm", required=True)
    ap.add_argument("--scenario", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--prereg", required=True)
    ap.add_argument("--root", required=True, help="pentest-agent repo root (has src/, config.yaml)")
    ap.add_argument("--rundir", required=True)
    ap.add_argument("--config", default=None, help="base config.yaml (default <root>/config.yaml)")
    ap.add_argument("--scenarios", default=None,
                    help="scenarios yaml (default <root>/eval/scenarios.yaml)")
    args = ap.parse_args()

    sys.path.insert(0, args.root)
    from src.orchestrator import Orchestrator, Scenario, load_config

    prereg = json.load(open(args.prereg, encoding="utf-8"))
    if args.arm not in prereg["arm_component_dicts"]:
        raise SystemExit(f"arm {args.arm} not in frozen prereg")
    comp = dict(prereg["arm_component_dicts"][args.arm])  # FROZEN dict

    cfg_path = args.config or os.path.join(args.root, "config.yaml")
    scen_path = args.scenarios or os.path.join(args.root, "eval", "scenarios.yaml")
    cfg = load_config(cfg_path)
    # IJIES-P2-MARKERS: config-driven oracle markers for cross-app confirmatory
    _om = cfg.get("oracle_markers") or {}
    if _om:
        from src.orchestrator import set_sqli_row_markers, set_blind_markers
        if _om.get("sqli"):
            set_sqli_row_markers(list(_om["sqli"]))
        if _om.get("blind_exists") or _om.get("blind_missing"):
            set_blind_markers(exists=_om.get("blind_exists"), missing=_om.get("blind_missing"))

    scen = next(Scenario.from_dict(s) for s in
                yaml.safe_load(open(scen_path, encoding="utf-8"))["scenarios"]
                if str(s["id"]) == args.scenario)

    cfg["components"] = comp
    cfg["model"]["name"] = {"q25": "qwen2.5:latest", "q35": "qwen3.5:latest"}.get(
        args.model, args.model)
    cfg["model"]["seed"] = args.seed
    # Matched stopping contract for EVERY arm (reviewer R2-A, R1-I).
    cfg["run"]["max_iterations"] = prereg["budget"]["max_iterations"]
    cfg["run"]["max_wall_clock_s"] = prereg["budget"]["max_wall_clock_s"]

    os.makedirs(args.rundir, exist_ok=True)
    rep = Orchestrator(cfg, scen, run_id=args.rid).run()
    # stamp provenance so analysis can verify the cell traces to the freeze + arm
    rep.setdefault("_meta", {})
    rep["_meta"].update({"arm": args.arm, "scenario": args.scenario, "model": args.model,
                         "seed": args.seed, "freeze_sha": prereg["freeze_sha"],
                         "arm_hash": prereg["arm_hashes"][args.arm]})
    with open(os.path.join(args.rundir, "report.json"), "w", encoding="utf-8") as fh:
        json.dump(rep, fh, indent=2)
    print(f"{args.rid} success={rep.get('success')} it={rep.get('iterations_used')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
