#!/usr/bin/env python3
"""P5 -- public-controller comparison OR sanctioned fallback (reviewer R2-C).

R2-C: "test at least one recent runnable controller under the same weights, target
information, tool permissions, trial budget, and outcome criterion. If a baseline
cannot be adapted without changing its design, document the limitation and narrow
the comparative claim."

Two modes (controller_config.json -> mode):
  fallback : write controller_limitation.md (reason + narrowed claim). 0 runs.
  run      : run the controller as ONE arm on a public subset under MATCHED conditions,
             score its OUTPUT with OUR oracle (not the controller's own claim), and
             emit controller_compare.csv next to our arms' OSR.

The controller is scored by the SAME deterministic evidence oracle used for every
arm, so "outcome criterion" is matched by construction. The adapter command must run
the controller WITHOUT altering its design; if that is impossible, use fallback.

Usage (pod, run mode):
    python phase_code/run_controller_compare.py --root <ROOT> \
        --config phase_code/controller_config.json [--target-url http://localhost/dvwa]
"""
import argparse, csv, json, os, subprocess, sys, tempfile


def write_fallback(cfg):
    fb = cfg["fallback"]
    md = ("# Controller comparison -- limitation (reviewer R2-C)\n\n"
          f"**Controller considered:** {cfg['run'].get('controller_name','?')} "
          f"(commit {cfg['run'].get('controller_commit','?')}).\n\n"
          f"**Why not run head-to-head:** {fb['reason']}\n\n"
          f"**Narrowed comparative claim:** {fb['narrowed_claim']}\n\n"
          "This uses the fallback path explicitly permitted by R2-C: *\"If a baseline "
          "cannot be adapted without changing its design, document the limitation and "
          "narrow the comparative claim.\"*\n")
    os.makedirs("results", exist_ok=True)
    open("results/controller_limitation.md", "w", encoding="utf-8").write(md)
    print("FALLBACK written -> results/controller_limitation.md")
    return 0


def score_with_oracle(root, scen_id, transcript_path):
    """Score a controller transcript with the project oracle (same as our arms).

    The project oracle is signal-based: src.reasoning.oracle_universal.UniversalOracle
    .judge(signals) over Signal objects (differential_signal / marker_signal /
    browser_exec_signal / time_based_signal / oast_signal). To score a FOREIGN
    controller under the SAME outcome criterion (R2-C), the transcript's final evidence
    must be converted into those Signal objects HERE -- this is the one adapter point
    that depends on the controller's transcript shape and MUST be wired before a run.

    Returns (success:int, signal:str). The function refuses to guess: if the evidence
    cannot be mapped to oracle signals, it raises so the caller marks the cell INVALID
    rather than crediting the controller's own claim.
    """
    sys.path.insert(0, root)
    from src.reasoning.oracle_universal import UniversalOracle  # signal-based judge
    with open(transcript_path, encoding="utf-8") as fh:
        transcript = json.load(fh)
    signals = build_signals_from_transcript(scen_id, transcript)  # adapter -- see below
    verdict = UniversalOracle().judge(signals)
    return int(bool(verdict.success())), getattr(verdict, "reason", "")


def build_signals_from_transcript(scen_id, transcript):
    """ADAPTER (must be filled per controller): map the controller's final evidence to
    project oracle Signal objects. Intentionally unimplemented so no controller result
    is silently credited without real evidence mapping (FIF honesty)."""
    raise NotImplementedError(
        "Wire the controller transcript's final evidence to oracle signals "
        "(differential_signal/marker_signal/browser_exec_signal/...) before running. "
        "Until then, use mode='fallback'.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--config", default=os.path.join(os.path.dirname(__file__),
                                                      "controller_config.json"))
    ap.add_argument("--target-url", default="http://localhost/dvwa")
    args = ap.parse_args()
    cfg = json.load(open(args.config, encoding="utf-8"))

    if cfg.get("mode") == "fallback":
        return write_fallback(cfg)

    run = cfg["run"]
    if "FILL" in str(run.get("adapter_cmd", "")):
        raise SystemExit("adapter_cmd not set. Fill it, or switch mode to 'fallback'.")

    import yaml
    scen_all = {str(s["id"]): s for s in
                yaml.safe_load(open(os.path.join(args.root, "eval", "scenarios.yaml"),
                                    encoding="utf-8"))["scenarios"]}
    rows = []
    for sid in run["scenarios"]:
        s = scen_all[sid]
        for seed in run["seeds"]:
            with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as tf:
                out = tf.name
            cmd = run["adapter_cmd"].format(
                out=out, endpoint=s["endpoint"], param=s["param"],
                method=s.get("method", "GET"), target_url=args.target_url,
                model=run["model"])
            rc = subprocess.run(cmd, shell=True).returncode
            succ, signal, valid = "", "", "invalid"
            if rc == 0 and os.path.exists(out):
                try:
                    succ, signal = score_with_oracle(args.root, sid, out)
                    valid = "valid"
                except Exception as e:  # noqa: BLE001
                    signal = f"oracle_error:{type(e).__name__}"
            rows.append({"controller": run["controller_name"], "scenario": sid,
                         "seed": seed, "success": succ, "signal": signal,
                         "validity": valid, "transcript": out})
            print(f"  {sid} s{seed} rc={rc} success={succ} {signal}")

    os.makedirs("results", exist_ok=True)
    with open("results/controller_compare.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["controller", "scenario", "seed", "success",
                                           "signal", "validity", "transcript"])
        w.writeheader(); w.writerows(rows)
    valid = [r for r in rows if r["validity"] == "valid"]
    osr = (round(100 * sum(r["success"] for r in valid) / len(valid), 2)
           if valid else None)
    print(json.dumps({"controller": run["controller_name"], "scored": len(valid),
                      "osr_pp": osr,
                      "note": "scored by OUR oracle under matched weights/budget/criterion "
                              "(R2-C); compare to our arms' OSR on the same subset."},
                     indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
