"""Build P4 replay_config.json from q25 credited stored/DOM XSS runs.
For each credited run: extract endpoint/param/winning-payload from trace + provenance.
Winning payload = last HTTP_REQUEST payload on the xss endpoint before success.
Run on pod: .venv/bin/python phase_code/build_p4_config.py"""
import json, glob, os

ROOT = "/workspace/pentest-agent"
OUT = os.path.join(ROOT, "phase_code", "replay_config.json")

def level_of(scn):
    for lv in ("low", "medium", "high"):
        if scn.endswith("_" + lv):
            return lv
    return "low"

def extract_case(rundir):
    rep = json.load(open(os.path.join(rundir, "report.json")))
    if not rep.get("success"):
        return None
    meta = rep.get("_meta", {})
    scn = meta.get("scenario", "")
    # walk trace: collect xss-endpoint HTTP_REQUESTs; keep the last one with a payload
    ep = param = payload = method = None
    extra = {}
    tp = os.path.join(rundir, "trace.jsonl")
    if not os.path.exists(tp):
        return None
    for line in open(tp, encoding="utf-8"):
        try:
            d = json.loads(line)
        except Exception:
            continue
        a = d.get("action", {}) or {}
        p = a.get("params", {}) or {}
        if a.get("type") == "HTTP_REQUEST" and p.get("value") and ("xss" in str(p.get("endpoint", "")).lower()):
            ep = p.get("endpoint"); param = p.get("param"); payload = p.get("value")
            method = (p.get("method") or "GET").upper()
            extra = p.get("extra_params") or {}
    if not (ep and param and payload):
        return None
    return {
        "scenario": scn, "arm": meta.get("config"), "model": meta.get("model", "q25"),
        "seed": meta.get("seed"), "source_run_id": rep.get("run_id") or os.path.basename(rundir),
        "endpoint": ep, "param": param, "payload": payload, "method": method or "GET",
        "extra_params": extra, "security_level": level_of(scn),
    }

def main():
    cases, skipped = [], 0
    dirs = sorted(glob.glob(os.path.join(ROOT, "runs", "k2b-*-q25-xss_stored_*")) +
                  glob.glob(os.path.join(ROOT, "runs", "k2b-*-q25-xss_dom_*")))
    for d in dirs:
        try:
            c = extract_case(d)
        except Exception:
            c = None
        if c:
            cases.append(c)
        else:
            skipped += 1
    cfg = {
        "_comment": "P4 stored/DOM XSS replay — populated from q25 credited runs. Controlled "
                    "replay on an ISOLATED DVWA (own DB dvwa_iso). SEPARATE MEASUREMENT, not pooled "
                    "with online OSR. Guestbook reset before each case (patched runner).",
        "mode": "isolated_replay",
        "isolation": {
            "base_url": "http://127.0.0.1/dvwa_iso",
            "allowlist": ["127.0.0.1", "localhost"],
            "login_user": "admin", "login_pass": "password",
            "app": "dvwa", "separate_datastore": True,
            "reset_sql": "DELETE FROM dvwa_iso.guestbook;",
            "proof": "isolated DB 'dvwa_iso' (distinct from campaign DB 'dvwa'); guestbook "
                     "truncated before each case so no case inherits another's stored payload.",
        },
        "cases": cases,
    }
    json.dump(cfg, open(OUT, "w", encoding="utf-8"), indent=2)
    print("cases=%d skipped=%d -> %s" % (len(cases), skipped, OUT))
    # family tally
    fam = {}
    for c in cases:
        f = c["scenario"]
        fam[f] = fam.get(f, 0) + 1
    for k in sorted(fam):
        print("  %-22s %d" % (k, fam[k]))

if __name__ == "__main__":
    main()
