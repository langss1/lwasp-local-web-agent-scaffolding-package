#!/usr/bin/env python3
"""P8 -- assemble the reproduction artifact ON THE POD (reviewer R1-G, +R1-A run, +R1-E).

Gathers everything a reader needs to reproduce the reported numbers:
  run_ledger.csv  -- EVERY cell (historical + new): config, scenario, seed, task_order,
                     budget, validity_reason, evidence_verdict, report_sha16 (R1-G per-run).
  oracle_spec.json-- per-scenario oracle rule: target effect, precondition, required
                     evidence, endpoint/method/param (R1-A run part; narrative table local).
  digests.json    -- sha256 of model weights + embedding + app/dependency versions +
                     pinned ollama tag (R1-G weight digests).
  arm_configs.json-- base/simple_tooled/full/ablation component dicts + hashes.
  rag_corpus_manifest.json -- RAG corpus files + hashes (if present).
Then tars phase_code/* (runner+reset+oracle+analysis) into a controlled-access bundle
with sensitive trace fields redacted.

Runs on the pod (reads runs/, config, scenarios, ollama blobs). No new agent runs.

Usage (pod):
    python phase_code/export_repro.py --root /workspace/pentest-agent \
        [--runs runs runs_timing] [--out results/repro_artifact]
"""
import argparse, csv, glob, hashlib, json, os, subprocess, sys, tarfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
LEDGER_FIELDS = ["config", "model", "scenario", "seed", "task_order", "budget_iters",
                 "wall_clock_s", "validity_reason", "evidence_verdict", "success",
                 "report_sha16", "rid", "runs_dir"]
REDACT_KEYS = ("prompt", "raw_body", "body", "transcript", "messages", "response_text",
               "dom_snapshot", "cookie", "payload")


def sha16(b):
    return hashlib.sha256(b).hexdigest()[:16]


def ledger_row(rp, rid, runs_dir, order):
    try:
        with open(rp, "rb") as fh:
            raw = fh.read()
    except OSError:
        return None
    try:
        rep = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeError):
        return {"rid": rid, "runs_dir": os.path.basename(runs_dir),
                "validity_reason": "unreadable_json", "success": "",
                "report_sha16": sha16(raw), "task_order": order}
    meta = rep.get("_meta", {}) if isinstance(rep, dict) else {}
    valid = "valid"
    if rep.get("invalid"):
        valid = "invalid:" + str(rep.get("finish_reason", ""))
    return {
        "config": meta.get("arm", meta.get("config", "")),
        "model": meta.get("model", ""), "scenario": meta.get("scenario", ""),
        "seed": meta.get("seed", ""), "task_order": order,
        "budget_iters": rep.get("max_iterations", rep.get("budget", "")),
        "wall_clock_s": rep.get("wall_clock_s", ""),
        "validity_reason": valid,
        "evidence_verdict": ("credited" if rep.get("success") else "not_credited"),
        "success": int(bool(rep.get("success"))),
        "report_sha16": sha16(raw), "rid": rid,
        "runs_dir": os.path.basename(runs_dir),
    }


def build_ledger(root, runs_dirs, out):
    rows = []
    for rd in runs_dirs:
        rdp = rd if os.path.isabs(rd) else os.path.join(root, rd)
        if not os.path.isdir(rdp):
            continue
        for order, cell in enumerate(sorted(os.listdir(rdp))):
            rp = os.path.join(rdp, cell, "report.json")
            if os.path.exists(rp):
                r = ledger_row(rp, cell, rdp, order)
                if r:
                    rows.append(r)
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=LEDGER_FIELDS, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    return len(rows)


def build_oracle_spec(root, out):
    import yaml
    spec = {}
    for name in ("scenarios.yaml", "scenarios_bwapp.yaml", "scenarios_juiceshop.yaml"):
        p = os.path.join(root, "eval", name)
        if not os.path.exists(p):
            continue
        for s in yaml.safe_load(open(p, encoding="utf-8"))["scenarios"]:
            spec[str(s["id"])] = {
                "vuln_type": s.get("vuln_type"), "level": s.get("level"),
                "endpoint": s.get("endpoint"), "method": s.get("method"),
                "param": s.get("param"), "precondition_extra_params": s.get("extra_params"),
                "required_evidence": s.get("success_condition"),
                "target_effect": s.get("description", "").strip(),
                "auth": "app login (dvwa/bwapp) per reset_contract; login-less for juiceshop",
                "state_reset": "per-unit clean snapshot (see confirmatory_reset_log.csv)",
            }
    json.dump(spec, open(out, "w", encoding="utf-8"), indent=2)
    return len(spec)


def build_digests(root, out):
    d = {"generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"), "ollama_pin": "0.40.17"}
    # ollama model blob digests
    try:
        d["ollama_models"] = subprocess.run(
            ["ollama", "list"], capture_output=True, text=True, timeout=30).stdout
    except Exception as e:  # noqa: BLE001
        d["ollama_models"] = f"unavailable:{e}"
    # python deps
    try:
        d["pip_freeze"] = subprocess.run(
            [sys.executable, "-m", "pip", "freeze"], capture_output=True, text=True,
            timeout=60).stdout
    except Exception as e:  # noqa: BLE001
        d["pip_freeze"] = f"unavailable:{e}"
    # weight blob sha (ollama stores blobs under ~/.ollama or OLLAMA_MODELS)
    blobs = []
    mroot = os.environ.get("OLLAMA_MODELS", os.path.expanduser("~/.ollama")) + "/blobs"
    for b in glob.glob(os.path.join(mroot, "sha256-*"))[:50]:
        blobs.append({"blob": os.path.basename(b), "bytes": os.path.getsize(b)})
    d["weight_blobs"] = blobs
    json.dump(d, open(out, "w", encoding="utf-8"), indent=2)
    return d


def build_arm_configs(out):
    sys.path.insert(0, HERE)
    import arms
    arms.assert_invariants()
    json.dump({"arms": arms.ARMS,
               "arm_hashes": {k: hashlib.sha256(
                   json.dumps(v, sort_keys=True).encode()).hexdigest()[:16]
                   for k, v in arms.ARMS.items()},
               "access_axis": arms.ACCESS_COMPONENTS,
               "orchestration_axis": arms.ORCHESTRATION_COMPONENTS},
              open(out, "w", encoding="utf-8"), indent=2)


def build_rag_manifest(root, out):
    man = []
    for base in ("knowledge", "rag_corpus", "corpus"):
        d = os.path.join(root, base)
        if os.path.isdir(d):
            for p in glob.glob(os.path.join(d, "**", "*"), recursive=True):
                if os.path.isfile(p):
                    with open(p, "rb") as fh:
                        man.append({"path": os.path.relpath(p, root),
                                    "sha16": sha16(fh.read())})
    json.dump({"files": man, "n": len(man)}, open(out, "w", encoding="utf-8"), indent=2)
    return len(man)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--runs", nargs="+", default=["runs", "runs_timing"])
    ap.add_argument("--out", default="results/repro_artifact")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    n_ledger = build_ledger(args.root, args.runs, os.path.join(args.out, "run_ledger.csv"))
    n_oracle = build_oracle_spec(args.root, os.path.join(args.out, "oracle_spec.json"))
    build_digests(args.root, os.path.join(args.out, "digests.json"))
    build_arm_configs(os.path.join(args.out, "arm_configs.json"))
    n_rag = build_rag_manifest(args.root, os.path.join(args.out, "rag_corpus_manifest.json"))

    # bundle phase_code (runner/reset/oracle/analysis) -- code only, no sensitive traces
    stamp = time.strftime("%Y%m%d_%H%M%S")
    tarpath = os.path.join(args.out, f"repro_artifact_{stamp}.tar")
    with tarfile.open(tarpath, "w") as tar:
        for f in sorted(glob.glob(os.path.join(HERE, "*.py")) +
                        glob.glob(os.path.join(HERE, "*.md")) +
                        glob.glob(os.path.join(HERE, "*.json"))):
            tar.add(f, arcname="phase_code/" + os.path.basename(f))
        for f in ("run_ledger.csv", "oracle_spec.json", "digests.json",
                  "arm_configs.json", "rag_corpus_manifest.json"):
            fp = os.path.join(args.out, f)
            if os.path.exists(fp):
                tar.add(fp, arcname=f)

    summary = {"run_ledger_rows": n_ledger, "oracle_scenarios": n_oracle,
               "rag_files": n_rag, "tarball": tarpath,
               "note": "controlled-access: bundle excludes raw traces; redact fields "
                       f"{REDACT_KEYS} from any trace export before release (R1-G)."}
    json.dump(summary, open(os.path.join(args.out, "export_summary.json"), "w",
                            encoding="utf-8"), indent=2)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
