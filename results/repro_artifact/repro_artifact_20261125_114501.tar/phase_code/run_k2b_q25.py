"""k2b 2x2 interaction campaign for q25 -- the missing twin of the q35 2x2 (reviewer R2.5).

WHY THIS EXISTS
  The 2x2 RAG x Guardrail interaction (FULL / L-RAG / I-RG10 / I-RG00) was run for q35
  only (campaign_audit_20261123: 6 configs x 116-117 rows; interaction FULL vs I-RG00 =
  -37pp, p=1.8e-9). The paper's method compares TWO local models, so to claim the
  interaction holds across models (symmetric with K1), we run the SAME four cells for q25.

WHAT IT RUNS
  4 configs x 39 pinned DVWA scenarios x 3 seeds (42,7,123) = 468 runs, model qwen2.5.
  The four configs are FULL with a leave-toggle, IDENTICAL to the q35 k2b definitions:
    FULL   (RG11) = {} .................. all components on
    L-RAG  (RG01) = {"rag": False} ...... RAG off, guardrail on
    I-RG10 (RG10) = {"guardrail": False}  RAG on, guardrail off
    I-RG00 (RG00) = {"rag": False, "guardrail": False}  both off  <- key interaction cell

HONESTY GATE (read before launching on the pod)
  The FULL dict below is copied VERBATIM from eval/run_ablation_loo.py (the in-repo
  authoritative L3 definition, "identical to eval/one_run_seed.py L3 branch"). The q35
  k2b cells came from the same codebase. BEFORE running, diff this FULL dict + the four
  overrides against the pod's actual k2b runner / a stored q35 k2b report's component
  dict. This script PRINTS the sha16 of each config's component dict and writes them to
  results/k2b_q25_arm_hashes.json so a mismatch with q35 is visible, not silent. If the
  hashes differ from q35, STOP -- the cross-model comparison would be invalid.

  Termination, reset, budget, and fix_retry are UNCHANGED from the ablation runner, so
  q25 cells are scored under the same contract as q35.

Usage (on pod, in venv, from repo ROOT that has src/orchestrator + config.yaml):
    python phase_code/run_k2b_q25.py --root /workspace/ta
  Resume-safe: re-launching skips (config,scenario,seed) triples already in k2b_q25.csv.
"""
import argparse, csv, hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

MTAG, MODEL = "q25", "qwen2.5:latest"
SEEDS = [42, 7, 123]
PREFIX = "k2b"

# Full (L3) baseline toggles -- VERBATIM from eval/run_ablation_loo.py (do not "improve").
FULL = {"pure_mode": False,
        "working_memory": True, "rag": True, "reflection": True, "guardrail": True,
        "state_graph": True, "tools_mcp": True, "sandbox": True, "auto_verify_xss": True,
        "long_term_memory": False, "web_search": False, "web_search_fallback": False,
        "skills": False, "eyes_ml": True, "progress_protection": True, "use_promise": True}

# The 2x2 cells = FULL with the listed keys overridden. Order matches k2b cell_map.
CONFIGS = [
    ("FULL",   {}),
    ("L-RAG",  {"rag": False}),
    ("I-RG10", {"guardrail": False}),
    ("I-RG00", {"rag": False, "guardrail": False}),
]

# The EXACT 39 non-captcha scenarios the q35 2x2 (and the main sweep) used.
SWEEP_SCENARIOS = {
    "blind_sqli_high", "blind_sqli_low", "blind_sqli_medium",
    "brute_high", "brute_low", "brute_medium",
    "cmdi_high", "cmdi_low", "cmdi_medium",
    "csrf_high", "csrf_low", "csrf_medium",
    "fi_high", "fi_low", "fi_medium",
    "js_high", "js_low", "js_medium",
    "open_redirect_high", "open_redirect_low", "open_redirect_medium",
    "sqli_high", "sqli_low", "sqli_medium",
    "upload_high", "upload_low", "upload_medium",
    "weak_session_high", "weak_session_low", "weak_session_medium",
    "xss_dom_high", "xss_dom_low", "xss_dom_medium",
    "xss_reflected_high", "xss_reflected_low", "xss_reflected_medium",
    "xss_stored_high", "xss_stored_low", "xss_stored_medium",
}


def comp_sha16(d):
    return hashlib.sha256(json.dumps(d, sort_keys=True).encode()).hexdigest()[:16]


def reset_dvwa_state():
    """Pollution guard (same as the ablation runner): restore admin creds before each run."""
    try:
        subprocess.run(
            ["mariadb", "-uroot", "-e",
             "USE dvwa; UPDATE users SET password=md5('password') WHERE user='admin';"],
            timeout=15, check=False,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass


def scenarios(root):
    import yaml
    data = yaml.safe_load(open(root / "eval" / "scenarios.yaml", encoding="utf-8"))["scenarios"]
    seen, sc = set(), []
    for s in data:
        sid = str(s["id"])
        if sid in SWEEP_SCENARIOS and sid not in seen:
            seen.add(sid)
            sc.append(s)
    missing = SWEEP_SCENARIOS - seen
    assert not missing, f"scenarios.yaml missing sweep scenarios: {sorted(missing)}"
    assert len(sc) == 39, f"expected 39 pinned scenarios, got {len(sc)}"
    return sc


def dump_arm_hashes():
    """Record the component dict + sha16 of each cell so q25<->q35 parity is auditable."""
    os.makedirs("results", exist_ok=True)
    out = {}
    for cname, ov in CONFIGS:
        comp = dict(FULL); comp.update(ov)
        out[cname] = {"override": ov, "component_sha16": comp_sha16(comp), "components": comp}
    json.dump(out, open("results/k2b_q25_arm_hashes.json", "w", encoding="utf-8"), indent=2)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="repo root on the pod (has src/, config.yaml, eval/)")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    sys.path.insert(0, str(root))
    from src.orchestrator import Orchestrator, Scenario, load_config

    hashes = dump_arm_hashes()
    print("=== k2b q25 2x2 -- component dict sha16 (diff against q35 before trusting) ===")
    for cname, meta in hashes.items():
        print(f"    {cname:8s} override={meta['override']!s:42s} sha16={meta['component_sha16']}")
    print("    -> results/k2b_q25_arm_hashes.json")

    scens = scenarios(root)
    total = len(CONFIGS) * len(scens) * len(SEEDS)
    print(f"k2b q25 2x2: {len(CONFIGS)} cfg x {len(scens)} scen x {len(SEEDS)} seed = {total} runs",
          flush=True)

    out_csv = root / "k2b_q25.csv"
    newfile = not out_csv.exists()
    done_triples = set()
    if not newfile:
        with open(out_csv, newline="", encoding="utf-8") as rf:
            for row in csv.reader(rf):
                if len(row) >= 3 and row[0] != "config":
                    done_triples.add((row[0], row[1], row[2]))
    print(f"RESUME: {len(done_triples)} runs already recorded -> skipped", flush=True)

    f = open(out_csv, "a", newline="", encoding="utf-8")
    w = csv.writer(f)
    if newfile:
        w.writerow(["config", "scenario", "seed", "success", "iters", "wall",
                    "guardrail_blocks", "backtracks", "tokens", "peak_vram_mb",
                    "finish_reason", "component_sha16"])

    done, errors = len(done_triples), 0
    for cname, override in CONFIGS:
        comp = dict(FULL); comp.update(override)
        csha = comp_sha16(comp)
        print(f"=== CONFIG {cname} (override={override}) sha16={csha} ===", flush=True)
        for sd in SEEDS:
            for s in scens:
                sid = s["id"]
                if (cname, sid, str(sd)) in done_triples:
                    continue
                rid = f"{PREFIX}-{cname}-{MTAG}-{sid}-s{sd}"
                rd = root / "runs" / rid
                if rd.exists():
                    shutil.rmtree(rd, ignore_errors=True)
                try:
                    scen = Scenario.from_dict(s)
                    cfg = load_config(root / "config.yaml")
                    cfg["components"] = comp
                    cfg["model"]["name"] = MODEL
                    cfg["model"]["seed"] = sd
                    cfg.setdefault("run", {})["fix_retry"] = False  # ablation = base behaviour
                    reset_dvwa_state()
                    rep = Orchestrator(cfg, scen, run_id=rid).run()
                    # stamp provenance into the stored report so cells are self-describing
                    rp = rd / "report.json"
                    if rp.exists():
                        d = json.load(open(rp, encoding="utf-8"))
                        d.setdefault("_meta", {}).update(
                            {"campaign": "k2b_2x2_q25", "config": cname, "model": MTAG,
                             "scenario": sid, "seed": sd, "component_sha16": csha})
                        json.dump(d, open(rp, "w", encoding="utf-8"))
                    row = [cname, sid, sd, int(bool(rep.get("success"))),
                           rep.get("iterations_used"), round(rep.get("wall_clock_s", 0)),
                           rep.get("guardrail_blocks", ""), rep.get("backtracks", ""),
                           rep.get("tokens_used", ""), rep.get("peak_vram_mb", ""),
                           rep.get("finish_reason", ""), csha]
                    msg = (f"success={rep.get('success')} it={rep.get('iterations_used')} "
                           f"wall={rep.get('wall_clock_s', 0):.0f}s")
                except Exception as e:  # one run failing must not abort the batch
                    errors += 1
                    row = [cname, sid, sd, 0, "", "", "", "", "", "",
                           f"error:{type(e).__name__}", csha]
                    msg = f"ERROR {type(e).__name__}: {str(e)[:80]} -> success=0, continuing"
                w.writerow(row); f.flush(); done += 1
                print(f"  [{done}/{total}] {cname} {sid} s{sd} {msg}", flush=True)
    f.close()
    print(f"K2B_Q25_ALLDONE (errors={errors})", flush=True)


if __name__ == "__main__":
    main()
