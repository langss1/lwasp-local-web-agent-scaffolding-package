#!/usr/bin/env python3
"""P3 step 3 -- aggregate per-phase timing (reviewer R1-I).

Reads timing-instrumented reports, verifies the no-double-count contract
(gen+action+verify+other == wall within 1%), and aggregates per arm:
  mean t_gen_s / t_action_s / t_verify_s / t_other_s, iterations, stop reason.
Explains the Base-15-iterations vs Full-stops-early contrast from the STOPPING
CONTRACT (verify-driven early stop), not from reasoning quality.

Usage:
    python phase_code/analyze_timing.py [--runs runs_timing]
"""
import argparse, csv, json, os, statistics

TIMERS = ["t_gen_s", "t_action_s", "t_verify_s", "t_other_s"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs_timing")
    args = ap.parse_args()
    runs_dir = os.path.abspath(args.runs)

    per_arm = {}
    dropped, rows = [], []
    for rid in sorted(os.listdir(runs_dir)) if os.path.isdir(runs_dir) else []:
        rp = os.path.join(runs_dir, rid, "report.json")
        if not os.path.exists(rp):
            continue
        try:
            rep = json.load(open(rp, encoding="utf-8"))
        except (ValueError, OSError):
            dropped.append((rid, "unreadable")); continue
        if any(k not in rep for k in TIMERS):
            dropped.append((rid, "no_timers")); continue
        wall = rep.get("wall_clock_s") or 0
        s = sum(rep[k] for k in TIMERS)
        if wall <= 0 or abs(s - wall) > 0.01 * wall:
            dropped.append((rid, f"sum_mismatch wall={wall:.1f} sum={s:.1f}")); continue
        arm = rep.get("_meta", {}).get("arm", rid.split("-")[1] if "-" in rid else "?")
        d = per_arm.setdefault(arm, {k: [] for k in TIMERS}
                               | {"iters": [], "success": [], "stop": {}})
        for k in TIMERS:
            d[k].append(rep[k])
        d["iters"].append(rep.get("iterations_used"))
        d["success"].append(int(bool(rep.get("success"))))
        sr = rep.get("finish_reason", "unknown")
        d["stop"][sr] = d["stop"].get(sr, 0) + 1
        rows.append({"rid": rid, "arm": arm, **{k: rep[k] for k in TIMERS},
                     "wall_clock_s": wall, "iterations_used": rep.get("iterations_used"),
                     "finish_reason": sr, "success": int(bool(rep.get("success")))})

    def mean(xs):
        xs = [x for x in xs if isinstance(x, (int, float))]
        return round(statistics.mean(xs), 2) if xs else None

    summary = {}
    for arm, d in per_arm.items():
        summary[arm] = {
            "n": len(d["iters"]),
            **{k: mean(d[k]) for k in TIMERS},
            "mean_iterations": mean(d["iters"]),
            "osr_pp": round(100 * statistics.mean(d["success"]), 1) if d["success"] else None,
            "stop_reasons": d["stop"],
        }
    out = {
        "per_arm": summary,
        "dropped_reports": dropped,
        "interpretation": (
            "R1-I: the gen/action/verify split is now explicit; t_other_s exposes "
            "model-load/parse-repair/oracle-replay that Table 5 previously folded into "
            "action. The iteration asymmetry follows the STOPPING CONTRACT: an arm with "
            "no verify activity never triggers the verified-FINISH early stop and spends "
            "its full iteration budget; an arm that verifies stops early. This is a "
            "contract difference, not a reasoning-quality difference."),
        "measurement": "reported as an ADDITIONAL instrumented measurement, not a "
                       "retrospective decomposition of the historical Table 5 runs.",
    }
    os.makedirs("results", exist_ok=True)
    json.dump(out, open("results/timing_summary.json", "w", encoding="utf-8"), indent=2)
    with open("results/timing_breakdown_v2.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["rid", "arm", *TIMERS, "wall_clock_s",
                                           "iterations_used", "finish_reason", "success"])
        w.writeheader(); w.writerows(rows)
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
