#!/usr/bin/env python3
"""P2 step 2 -- run the confirmatory campaign (reviewer R1-E, R2-B).

Interleaved, identical-state design:
  for each (scenario, model, seed) UNIT:
      1. RESET the target to a clean snapshot (db, cookies, persisted content,
         stored-XSS artifacts) and LOG the reset by condition   <- R1-E
      2. run all three arms back-to-back on that SAME fresh snapshot, each in its
         own crash-isolated subprocess, in a rotating arm order so no arm is
         systematically first                                    <- R2-B identical state
Resume-safe: a unit whose report.json already exists is skipped. The arm component
dicts come from the FROZEN prereg (freeze_sha stamped into every report).

Requires a prereg frozen by freeze_confirmatory.py and a reset command that
actually restores the target (NO default -- we never invent the reset; you supply
the real one and it is logged).

Usage (on pod, target up):
    python phase_code/run_confirmatory.py \
        --root /workspace/pentest-agent \
        --reset-cmd "bash /workspace/pentest-agent/eval/reset_dvwa.sh {app}" \
        [--prereg results/prereg_confirmatory.json] [--runs runs]
        [--cell-timeout 1500]
"""
import argparse, csv, json, os, shutil, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
PREREG_DEFAULT = os.path.join("results", "prereg_confirmatory.json")
RESET_LOG = os.path.join("results", "confirmatory_reset_log.csv")

# rotating arm order per unit so first-mover residue (if reset ever imperfect) is
# spread across arms, not biased to one.
ARM_ORDERS = [["base", "simple_tooled", "full"],
              ["simple_tooled", "full", "base"],
              ["full", "base", "simple_tooled"]]


def run_reset(reset_cmd, app, unit_id, log_rows):
    cmd = reset_cmd.format(app=app, unit=unit_id)
    t0 = time.time()
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    log_rows.append({"unit": unit_id, "app": app, "cmd": cmd, "rc": p.returncode,
                     "elapsed_s": round(time.time() - t0, 2),
                     "ok": p.returncode == 0,
                     "stderr_tail": (p.stderr or "")[-200:].replace("\n", " ")})
    return p.returncode == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="pentest-agent repo root on the pod")
    ap.add_argument("--reset-cmd", required=True,
                    help="shell cmd that resets the target to a clean snapshot; "
                         "{app} and {unit} are substituted. Must exit 0 on success.")
    ap.add_argument("--app", default="dvwa")
    ap.add_argument("--prereg", default=PREREG_DEFAULT)
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--cell-timeout", type=int, default=1500)
    # For a held-out confirmatory on an INDEPENDENT app (Juice Shop / bWAPP), point the
    # worker at that app's scenario file + a config whose base_url targets it. Omitted =
    # the worker's defaults (<root>/eval/scenarios.yaml, <root>/config.yaml = DVWA).
    ap.add_argument("--scenarios", default=None,
                    help="app scenario yaml, e.g. eval/scenarios_juiceshop.yaml")
    ap.add_argument("--config", default=None,
                    help="app config.yaml whose base_url targets --app")
    args = ap.parse_args()

    if not os.path.exists(args.prereg):
        raise SystemExit("No frozen prereg. Run freeze_confirmatory.py first (R2-B).")
    prereg = json.load(open(args.prereg, encoding="utf-8"))
    runs_dir = os.path.abspath(args.runs)
    os.makedirs("results", exist_ok=True)
    os.makedirs(runs_dir, exist_ok=True)

    scenarios, models, seeds = prereg["scenarios"], prereg["models"], prereg["seeds"]
    units = [(s, m, sd) for s in scenarios for m in models for sd in seeds]
    reset_log = []
    done = skipped = failed_reset = 0

    for ui, (scen, model, seed) in enumerate(units):
        unit_id = f"conf-{scen}-{model}-s{seed}"
        rids = {arm: f"conf-{arm}-{model}-{scen}-s{seed}"
                for arm in prereg["arms"]}
        # resume: if every arm's report already exists, skip the whole unit
        if all(os.path.exists(os.path.join(runs_dir, r, "report.json"))
               for r in rids.values()):
            skipped += 1
            continue
        # one clean snapshot for the whole unit
        if not run_reset(args.reset_cmd, args.app, unit_id, reset_log):
            failed_reset += 1
            print(f"[reset FAILED] {unit_id} -- skipping unit (will retry next run)")
            continue
        order = ARM_ORDERS[ui % len(ARM_ORDERS)]
        for arm in order:
            rid = rids[arm]
            rundir = os.path.join(runs_dir, rid)
            if os.path.exists(os.path.join(rundir, "report.json")):
                continue
            if os.path.isdir(rundir):
                shutil.rmtree(rundir, ignore_errors=True)  # partial -> fresh
            cmd = [sys.executable, os.path.join(HERE, "_conf_worker.py"),
                   "--rid", rid, "--arm", arm, "--scenario", scen,
                   "--model", model, "--seed", str(seed),
                   "--prereg", os.path.abspath(args.prereg),
                   "--root", args.root, "--rundir", rundir]
            if args.scenarios:
                cmd += ["--scenarios", args.scenarios]
            if args.config:
                cmd += ["--config", args.config]
            try:
                subprocess.run(cmd, timeout=args.cell_timeout)
            except subprocess.TimeoutExpired:
                # record an INVALID cell so the denominator logic can exclude it
                os.makedirs(rundir, exist_ok=True)
                json.dump({"success": False, "invalid": True,
                           "finish_reason": "cell_timeout",
                           "_meta": {"arm": arm, "scenario": scen, "model": model,
                                     "seed": seed, "freeze_sha": prereg["freeze_sha"]}},
                          open(os.path.join(rundir, "report.json"), "w"), indent=2)
            done += 1
        print(f"[{ui+1}/{len(units)}] {unit_id} order={order}")

    # flush reset log
    if reset_log:
        hdr = ["unit", "app", "cmd", "rc", "ok", "elapsed_s", "stderr_tail"]
        write_header = not os.path.exists(RESET_LOG)
        with open(RESET_LOG, "a", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=hdr)
            if write_header:
                w.writeheader()
            w.writerows(reset_log)

    print(json.dumps({"units": len(units), "unit_runs_done": done,
                      "units_skipped_complete": skipped,
                      "units_reset_failed": failed_reset,
                      "reset_log": RESET_LOG}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
