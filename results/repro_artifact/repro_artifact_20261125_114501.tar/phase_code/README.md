# phase_code — RunPod experiment phases (IJIES 426 revision)

Reviewer→phase map + how each phase connects: see
`../PETA_REVIEWER_KE_EKSPERIMEN.md`. All runners are config-driven, resume-safe,
crash-isolated per cell; status FINAL only when the full scheduled grid passes.

## Files
| File | Phase | Role |
|---|---|---|
| `reprovision_healthcheck.sh` | pre | resume re-provision + GO/NO-GO health gate |
| `pull_pod_results.sh` | P0 | archive (zstd) + scp the 373 2×2 cells to local, sha256-verified |
| `k2b_manifest.json` | P0/P1 | frozen roster (q35 × 4 cfg × 39 scn × 3 seed = 468) |
| `P0_verify_integrity.py` | P0 | per-cell reuse/rerun/review gate; exports report_sha16 |
| `P1_compute_interaction.py` | P1 | 2×2 interaction + cluster bootstrap CI (consumes P0 allowlist) |
| `arms.py` | P2 | canonical base/simple_tooled/full + R2-A access-parity / R1-B opportunity checks |
| `holdout_bwapp.txt` / `holdout_juiceshop.txt` | P2 | held-out confirmatory ids (independent apps, unseen scenarios) |
| `run_k2b_q25.py` + `k2b_manifest_q25.json` | R2.5 | q25 twin of the 2x2 interaction (q35 already complete) |
| `freeze_confirmatory.py` | P2 | write + lock prereg_confirmatory.json (freeze_sha) |
| `holdout_scenarios.txt` | P2 | DECISION A: frozen held-out IDs |
| `run_confirmatory.py` + `_conf_worker.py` | P2 | interleaved clean-snapshot run + reset_log |
| `analyze_confirmatory.py` | P2 | between-arm paired McNemar + Holm + opportunity note |
| `phase_timer.py` + `timing_patch_spec.md` | P3 | per-phase timers (no double-count) |
| `run_timing.py` + `timing_config.json` | P3 | DECISION B: timing subset |
| `analyze_timing.py` | P3 | gen/action/verify aggregation; drops sum≠wall |
| `replay_stored_dom.py` + `replay_config.json` | P4 | DECISION C: isolated stored/DOM evidence replay |
| `run_controller_compare.py` + `controller_config.json` | P5 | DECISION F: public-controller comparison (R2-C) or sanctioned fallback note |
| `export_repro.py` | P8 | on-pod reproduction artifact: run_ledger + oracle_spec + digests + tarball (R1-G) |
| `analyze_ledger.py` | P8 | recompute OSR from run_ledger.csv alone (ledger self-verifies) |

## Run order (ONE pod session, 2026-11-24 design)

Held-out confirmatory runs on INDEPENDENT apps (no clean DVWA held-out exists: 39/40
scenarios were used in dev). Timing rides along via PHASE_TIMING=1 (no separate run).

```
bash reprovision_healthcheck.sh                  # GO/NO-GO + smoke-check held-out ids
# apply timing_patch_spec.md to orchestrator.py (3 sites), so confirmatory also yields timing

# --- held-out confirmatory, PER APP (3 arms, interleaved, clean snapshot) ---
PHASE_TIMING=1 python freeze_confirmatory.py --holdout holdout_bwapp.txt --target bwapp \
    --models q35 --oracle <ROOT>/src/reasoning/oracle_universal.py
PHASE_TIMING=1 python run_confirmatory.py --root <ROOT> --app bwapp \
    --scenarios <ROOT>/eval/scenarios_bwapp.yaml --config <ROOT>/config_bwapp.yaml \
    --reset-cmd "<real bWAPP reset with {app}>"
# repeat the two commands with holdout_juiceshop.txt / --app juiceshop / scenarios_juiceshop.yaml
python analyze_confirmatory.py            # per-app paired McNemar + Holm + timing split
python analyze_timing.py                  # gen/action/verify from the PHASE_TIMING reports

# --- q25 2x2 (twin of q35; R2.5 cross-model interaction) ---
python run_k2b_q25.py --root <ROOT>                       # 4 cfg x 39 scen x 3 seed = 468
python P0_verify_integrity.py --manifest k2b_manifest_q25.json
python P1_compute_interaction.py --manifest k2b_manifest_q25.json

# --- light, no model ---
python replay_stored_dom.py --config replay_config.json --root <ROOT>   # optional XSS evidence
python export_repro.py                                                   # repro digests (R1.5/E.3)
```

Freeze is PER APP (bWAPP and Juice have different reset/target). q25 confirmatory is
optional (K1 already carries q25 dev-set evidence); add `--models q25 q35` to double it.

## Tested locally
P0 (8 cases + FINAL), P1 (8/8 regression + FINAL), P2 freeze→analyze (synthetic,
status FINAL, contrasts+McNemar+Holm correct), P3 analyzer (base 15-iter/stop
asymmetry + double-count guard drops bad report), P4 config-gate (refuses
non-isolated). P4 browser + all `--root` runs need the pod (playwright + live
targets). Running anything on the pod needs the user's explicit per-request go.
