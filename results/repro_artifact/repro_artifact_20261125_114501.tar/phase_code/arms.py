#!/usr/bin/env python3
"""Canonical arm definitions for the confirmatory campaign (P2) + parity checks.

SINGLE SOURCE OF TRUTH for the three K1 arms. The confirmatory run MUST use the
SAME component configuration as the development-set K1 run, otherwise the
confirmatory evidence is not comparable. We therefore:
  1. Define the three arms here from the verified component schema
     (src/orchestrator component flags; see run_base_extval.BASE and
      one_run_level.py SCAFF/OFF for the established pattern).
  2. Expose a PARITY CHECK (reviewer R2-A): `simple_tooled` must have the SAME
     execution / browser / verification / stopping access as `full`, and differ
     ONLY in the orchestration layer. If that invariant breaks, the contrast
     simple_tooled->full no longer isolates orchestration and the run must stop.
  3. Let freeze_confirmatory.py hash whatever dict is actually used, so any drift
     from the canonical K1 runner is auditable (reviewer R2-B "freeze package").

IMPORTANT (honesty): before the confirmatory run, confirm these three dicts are
byte-identical to the K1 runner's arms on the pod. The freeze hash makes a
mismatch visible; it does not silently fix one.

Reviewer anchors:
  R2-A -- "tool- and observation-matched simple agent ... distinguish the value of
           orchestration from access to execution and verification capabilities."
  R2-B -- "after freezing the final package and scoring criteria."
  R1-B -- opportunity parity: Base is HTTP_REQUEST only, so it cannot produce the
           verified non-FINISH trace the oracle requires for browser-only effects.
"""

# --- Component universe (exact keys from src/orchestrator component schema) ----
# Verified against reproduction/source_code/eval/run_base_extval.py (BASE) and
# one_run_level.py (SCAFF/OFF).
ALL_COMPONENTS = [
    "pure_mode",
    # --- EXECUTION / EVIDENCE / VERIFICATION access (the "capabilities" axis) ---
    "tools_mcp", "sandbox", "auto_verify_xss", "oracle_universal",
    # --- ORCHESTRATION (the "scaffolding brain" axis -- what the paper claims) ---
    "working_memory", "rag", "reflection", "state_graph", "recon",
    "context_summarizer", "bandit", "eyes_ml", "progress_protection", "use_promise",
    # --- SAFETY ---
    "guardrail",
    # --- anti-leak: OFF in every arm (kept identical so it is never a confound) ---
    "long_term_memory", "web_search", "web_search_fallback",
    "web_search_app4_only", "skills", "oast",
]

# The two axes the reviewer wants separated (R2-A).
ACCESS_COMPONENTS = ["tools_mcp", "sandbox", "auto_verify_xss", "oracle_universal"]
ORCHESTRATION_COMPONENTS = [
    "working_memory", "rag", "reflection", "state_graph", "recon",
    "context_summarizer", "bandit", "eyes_ml", "progress_protection", "use_promise",
]
# Access axis also governs opportunity-to-be-credited (R1-B) and early-stop
# ability (R1-I): an arm with auto_verify_xss/browser OFF cannot trigger the
# verified-FINISH early stop, so it exhausts the iteration budget.
ANTILEAK_OFF = ["long_term_memory", "web_search", "web_search_fallback",
                "web_search_app4_only", "skills", "oast"]


def _mk(pure, access, orch, guardrail):
    d = {k: False for k in ALL_COMPONENTS}
    d["pure_mode"] = pure
    for k in ACCESS_COMPONENTS:
        d[k] = access
    for k in ORCHESTRATION_COMPONENTS:
        d[k] = orch
    d["guardrail"] = guardrail
    for k in ANTILEAK_OFF:
        d[k] = False
    return d


# base = pure ReAct, HTTP_REQUEST only. IDENTICAL to run_base_extval.BASE.
BASE = _mk(pure=True, access=False, orch=False, guardrail=False)

# simple_tooled = tool-/observation-/verification-MATCHED to full, NO orchestration.
# Access ON (so it CAN be credited and CAN early-stop -- opportunity parity with
# full), orchestration OFF. This is the reviewer's R2-A "simple agent".
SIMPLE_TOOLED = _mk(pure=False, access=True, orch=False, guardrail=True)

# full = everything (access + orchestration + ML).
FULL = _mk(pure=False, access=True, orch=True, guardrail=True)

ARMS = {"base": BASE, "simple_tooled": SIMPLE_TOOLED, "full": FULL}


# --- F1 parity check (reviewer R2-A) -------------------------------------------
def access_parity(a, b):
    """True iff arms a,b share identical EXECUTION/VERIFICATION access.

    simple_tooled vs full MUST pass: same tools/browser/verify/oracle, so the only
    remaining difference is the orchestration axis.
    """
    return all(ARMS[a][k] == ARMS[b][k] for k in ACCESS_COMPONENTS)


def orchestration_delta(a, b):
    """Components that differ on the orchestration axis between a and b."""
    return [k for k in ORCHESTRATION_COMPONENTS if ARMS[a][k] != ARMS[b][k]]


def assert_invariants():
    """Fail loudly if the arm design violates what the reviewer asked for."""
    problems = []
    # R2-A core: simple_tooled and full share execution/verification access.
    if not access_parity("simple_tooled", "full"):
        diff = [k for k in ACCESS_COMPONENTS
                if ARMS["simple_tooled"][k] != ARMS["full"][k]]
        problems.append(f"simple_tooled vs full differ on ACCESS {diff} "
                        "-> contrast would NOT isolate orchestration (R2-A).")
    # simple_tooled must differ from full on at least one orchestration component,
    # else it is just full.
    if not orchestration_delta("simple_tooled", "full"):
        problems.append("simple_tooled == full on orchestration -> no contrast.")
    # base must be strictly the no-access arm (opportunity-parity narrative, R1-B).
    if any(ARMS["base"][k] for k in ACCESS_COMPONENTS):
        problems.append("base has execution/verification access -> not HTTP-only (R1-B).")
    # anti-leak identical across arms (never a confound).
    for arm in ARMS:
        if any(ARMS[arm][k] for k in ANTILEAK_OFF):
            problems.append(f"{arm}: anti-leak component ON -> confound.")
    if problems:
        raise AssertionError("ARM DESIGN VIOLATION:\n  - " + "\n  - ".join(problems))
    return True


# opportunity-to-be-credited per arm (R1-B): an arm can be credited for a
# browser-only effect only if it can run the browser verifier.
def can_be_credited_browser(arm):
    return ARMS[arm]["auto_verify_xss"]


if __name__ == "__main__":
    import json
    assert_invariants()
    print("ARM INVARIANTS OK (R2-A access parity, R1-B opportunity parity).")
    print("access_parity(simple_tooled, full):", access_parity("simple_tooled", "full"))
    print("orchestration_delta(simple_tooled, full):",
          orchestration_delta("simple_tooled", "full"))
    print(json.dumps(ARMS, indent=2))
