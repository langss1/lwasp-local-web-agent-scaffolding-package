#!/usr/bin/env python3
"""P1 - Factorial 2x2 interaction (revisi sesudah audit GPT).

WAJIB dijalankan SETELAH P0. P1 HANYA memakai sel yang disetujui P0 (decision=reuse)
dan memverifikasi report yang dianalisis = report yang dinilai P0 (cocok sha256).
Satu unit lengkap TIDAK lagi menghasilkan keluaran seolah final: status FINAL hanya
bila seluruh grid terjadwal (manifest) lengkap & lolos; selain itu berlabel PARTIAL.

    python revision_phase_code/P1_compute_interaction.py [--manifest PATH] [--runs runs]

Desain sel: RG11=FULL, RG01=L-RAG, RG10=I-RG10, RG00=I-RG00.
Interaksi = (OSR_RG11-OSR_RG01) - (OSR_RG10-OSR_RG00), pada unit complete-case
(keempat sel disetujui P0). CI = bootstrap klaster-skenario (seed 20261105, 20k,
resample skenario, pertahankan seed). <-- rumus & bootstrap dipertahankan (disetujui GPT).

Keluaran:
    results/k2b_interaction_result.json  (status FINAL/PARTIAL, OSR/sel, interaksi, CI,
                                          denominator, exclusions, missing)
    results/k2b_interaction_percell.csv
"""
import json, os, csv, random, statistics, hashlib, argparse, re

CELL = {"RG11": "FULL", "RG01": "L-RAG", "RG10": "I-RG10", "RG00": "I-RG00"}
BOOT_SEED, N_BOOT = 20261105, 20000
P0_CSV = "results/k2b_integrity_report.csv"


def load_manifest(path):
    return json.loads(open(path, encoding="utf-8").read())


def load_allowlist(runs_dir):
    """Require a PASS/reuse approval with a valid hash of the report bytes.

    Cache the outcome from those same verified bytes, so later file changes
    cannot slip between a hash check and a second read of the success field.
    """
    if not os.path.exists(P0_CSV):
        raise SystemExit("P0 belum dijalankan: results/k2b_integrity_report.csv tak ada. "
                         "Jalankan P0_verify_integrity.py dulu.")
    allow, mism = {}, []
    with open(P0_CSV, encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            if r.get("decision") != "reuse":
                continue
            rid = r.get("rid", "")
            expected_hash = r.get("report_sha16", "")
            if (r.get("status") != "PASS" or not rid
                    or not re.fullmatch(r"[0-9a-fA-F]{16}", expected_hash or "")):
                mism.append(rid or "<missing_run_id>")
                continue
            rp = os.path.join(runs_dir, rid, "report.json")
            try:
                with open(rp, "rb") as report_file:
                    raw = report_file.read()
            except OSError:
                mism.append(rid)
                continue
            h = hashlib.sha256(raw).hexdigest()[:16]
            if h != expected_hash.lower():
                mism.append(rid)
                continue
            try:
                rep = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeError):
                mism.append(rid)
                continue
            if not isinstance(rep, dict) or not isinstance(rep.get("success"), bool):
                mism.append(rid)
                continue
            allow[rid] = {"config": r["config"], "model": r["model"],
                          "scenario": r["scenario"], "seed": r["seed"],
                          "success": int(rep["success"]), "report_sha16": h}
    return allow, mism


def point_interaction(units):
    if not units:
        return None
    osr = {k: statistics.mean([u[k] for u in units]) for k in CELL}
    inter = (osr["RG11"] - osr["RG01"]) - (osr["RG10"] - osr["RG00"])
    return osr, inter


def bootstrap_ci(units):
    by = {}
    for u in units:
        by.setdefault(u["scenario"], []).append(u)
    scen = list(by)
    rng = random.Random(BOOT_SEED)
    out = []
    for _ in range(N_BOOT):
        samp = []
        for _ in scen:
            samp.extend(by[rng.choice(scen)])
        r = point_interaction(samp)
        if r:
            out.append(r[1])
    out.sort()
    return out[int(0.025 * len(out))], out[int(0.975 * len(out))]


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("--manifest", default=os.path.join(here, "k2b_manifest.json"))
    ap.add_argument("--runs", default="runs")
    args = ap.parse_args()
    man = load_manifest(args.manifest)
    os.makedirs("results", exist_ok=True)
    allow, mism = load_allowlist(args.runs)

    model = man["model"]
    scheduled_units = [(s, sd) for s in man["scenarios"] for sd in man["seeds"]]  # 117
    units, incomplete = [], []
    for s, sd in scheduled_units:
        got = {}
        for ck, cfg in CELL.items():
            rid = f"k2b-{cfg}-{model}-{s}-s{sd}"
            if rid in allow:
                got[ck] = allow[rid]["success"]
        if len(got) == 4:
            units.append({"scenario": s, "seed": sd, **got})
        else:
            incomplete.append({"scenario": s, "seed": sd,
                               "have": sorted(got), "missing": sorted(set(CELL) - set(got))})

    is_final = (len(units) == len(scheduled_units)) and not mism
    res = point_interaction(units)
    out = {
        "status": "FINAL" if is_final else "PARTIAL",
        "model": model,
        "scheduled_units": len(scheduled_units),
        "complete_case_units": len(units),
        "incomplete_units": len(incomplete),
        "p0_reuse_cells": len(allow),
        "p0_hash_mismatch_or_missing": mism,
        "denominator_note": f"{len(units)}/{len(scheduled_units)} unit (scenario x seed) lengkap & lolos P0",
    }
    if res:
        osr, inter = res
        lo, hi = bootstrap_ci(units)
        out.update({
            "osr_per_cell_pp": {k: round(100 * v, 2) for k, v in osr.items()},
            "interaction_pp": round(100 * inter, 2),
            "scenario_cluster_ci_pp": [round(100 * lo, 2), round(100 * hi, 2)],
            "ci_crosses_zero": bool(lo <= 0 <= hi),
            "boot": {"seed": BOOT_SEED, "n": N_BOOT},
        })
        if not is_final:
            out["WARNING"] = ("PARTIAL: angka interaksi ini SEMENTARA, bukan hasil final. "
                              "Jangan dilaporkan sebagai interaksi final sampai status FINAL.")
    else:
        out["WARNING"] = "Belum ada unit complete-case yang lolos P0; tak ada angka."

    json.dump(out, open("results/k2b_interaction_result.json", "w", encoding="utf-8"), indent=2)
    with open("results/k2b_interaction_percell.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["scenario", "seed", "RG11", "RG01", "RG10", "RG00", "within_unit_interaction"])
        for u in units:
            w.writerow([u["scenario"], u["seed"], u["RG11"], u["RG01"], u["RG10"], u["RG00"],
                        (u["RG11"] - u["RG01"]) - (u["RG10"] - u["RG00"])])
    # ekspor daftar unit tak lengkap utk transparansi
    json.dump(incomplete, open("results/k2b_interaction_incomplete.json", "w", encoding="utf-8"), indent=2)
    print(json.dumps(out, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
