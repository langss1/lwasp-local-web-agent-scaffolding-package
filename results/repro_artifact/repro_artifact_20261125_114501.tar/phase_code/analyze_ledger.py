#!/usr/bin/env python3
"""P8 companion -- reproduce headline OSR from run_ledger.csv ALONE (reviewer R1-G).

A reader must be able to recompute the reported numbers from the machine-readable
ledger without the raw traces. This aggregates OSR per (config, model) over VALID
cells and prints the denominators, so the ledger is self-verifying.

Usage:
    python phase_code/analyze_ledger.py --ledger results/repro_artifact/run_ledger.csv
"""
import argparse, csv, json
from collections import defaultdict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ledger", required=True)
    args = ap.parse_args()
    num = defaultdict(int); den = defaultdict(int); invalid = defaultdict(int)
    for r in csv.DictReader(open(args.ledger, encoding="utf-8-sig")):
        key = (r.get("config", ""), r.get("model", ""))
        if str(r.get("validity_reason", "")).startswith("valid"):
            den[key] += 1
            if str(r.get("success")) == "1":
                num[key] += 1
        else:
            invalid[key] += 1
    out = {}
    for key in sorted(set(den) | set(invalid)):
        cfg, model = key
        out[f"{cfg}|{model}"] = {
            "osr_pp": round(100 * num[key] / den[key], 2) if den[key] else None,
            "valid": f"{num[key]}/{den[key]}", "invalid": invalid[key]}
    print(json.dumps({"osr_per_config_model": out,
                      "note": "recomputed from ledger only (no raw traces)."}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
