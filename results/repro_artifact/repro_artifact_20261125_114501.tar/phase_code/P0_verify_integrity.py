#!/usr/bin/env python3
"""P0 - Integrity gate for the K2 2x2 cells (revisi sesudah audit GPT).

Tujuan: pastikan 373 sel yang sudah jalan TIDAK sia-sia. Sel lolos integritas -> REUSE;
hanya sel gagal -> RERUN; metadata/provenance kurang atau bukti meragukan -> REVIEW
(karantina, bukan otomatis reuse DAN bukan otomatis rerun semuanya).

Roster = MANIFEST BEKU `k2b_manifest.json` (4 cfg x 39 skenario x 3 seed x 1 model q35 = 468),
BUKAN disimpulkan dari folder yang kebetulan ada.

Jalankan di pod dari /workspace/pentest-agent:
    python revision_phase_code/P0_verify_integrity.py [--manifest PATH] [--runs runs]

Keluaran:
    results/k2b_integrity_report.csv   (per-sel: status, alasan, keputusan, hash report)
    results/k2b_integrity_summary.json (reuse/rerun/review/missing/unknown + grid terjadwal)

Perbaikan vs versi lama (audit GPT CODE-01..05):
  01 Roster dari manifest beku (1 model q35, 468), enumerasi missing dari manifest.
  02 Bukti nyata: verified harus boolean True dan screenshot berupa file non-kosong.
     Error verifier dibedakan dari kegagalan biasa alat/target di trace.jsonl.
  03 Marker lingkungan dibandingkan ke manifest; hilang/salah -> REVIEW, bukan reuse.
  04 (lihat P1) keputusan P0 di-ekspor + hash report utk dikonsumsi P1.
  05 wall_clock_s wajib angka hingga & non-negatif; identitas run divalidasi ke manifest.
"""
import json, os, sys, csv, glob, hashlib, argparse, math

REQ = {"success", "wall_clock_s"}
FATAL_BROWSER_MARKERS = (
    "targetclosederror", "browser closed unexpectedly", "browser has been closed",
    "executable doesn't exist", "host system is missing dependencies",
    "error while loading shared libraries",
)
ERROR_FIELDS = ("error", "exception", "error_type", "exception_type", "traceback")
TOOL_ACTIONS = {"RUN_SCRIPT", "RUN_TOOL"}


def load_manifest(path):
    m = json.loads(open(path, encoding="utf-8").read())
    m["_scen"] = set(m["scenarios"])
    m["_cfg"] = set(m["configs"])
    m["_seed"] = set(m["seeds"])
    return m


def parse_rid(rid, man):
    body = rid[len("k2b-"):] if rid.startswith("k2b-") else rid
    cfg = next((c for c in man["configs"] if body.startswith(c + "-")), None)
    if not cfg:
        return None
    rest = body[len(cfg) + 1:]
    model = man["model"]
    if not rest.startswith(model + "-"):
        return None
    rest = rest[len(model) + 1:]
    if "-s" not in rest:
        return None
    scenario, seed = rest.rsplit("-s", 1)
    return {"config": cfg, "model": model, "scenario": scenario, "seed": seed}


def is_finite_duration(v):
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return False
    try:
        f = float(v)
    except (TypeError, ValueError, OverflowError):
        return False
    return math.isfinite(f) and f >= 0.0


def error_issue(record, inherited_action="", inherited_source=""):
    """Return (FAIL|REVIEW, reason) for infrastructure/unclear errors only.

    Inspect error channels and verifier signals, not arbitrary payload/body text.
    A command's ordinary traceback is a valid agent/tool failure, not evidence
    that the independent outcome verifier or the host failed.
    """
    if not isinstance(record, dict):
        return "REVIEW", "error_record_not_object"
    action = record.get("action")
    action_type = action.get("type", "") if isinstance(action, dict) else ""
    action_type = str(action_type or inherited_action).upper()
    sources = [str(record.get(k, "")) for k in ("source", "component", "stage", "event")]
    source = " ".join([inherited_source, *sources]).lower()
    verifier_source = action_type == "VERIFY" or any(
        k in source for k in ("verifier", "verification", "browser", "playwright", "chromium")
    )
    ordinary_tool = action_type in TOOL_ACTIONS and not verifier_source
    pending = None
    for key in ERROR_FIELDS:
        value = record.get(key)
        if value in (None, "", False):
            continue
        text = (value if isinstance(value, str) else json.dumps(value)).lower()
        if ordinary_tool:
            continue
        if any(marker in text for marker in FATAL_BROWSER_MARKERS):
            return "FAIL", "verifier_infrastructure_error"
        # Generic stack traces or unclassified errors need review, not automatic
        # rerunning until a favorable outcome happens to be obtained.
        pending = ("REVIEW", "verifier_error_unclassified" if verifier_source
                   else "error_source_unclassified")
    signal = record.get("signal")
    if isinstance(signal, str):
        low = signal.lower()
        verifier_signal = any(x in low for x in (
            "auto-verify skipped", "browser verify could not interact",
            "browser verification failed", "verifier failed",
        ))
        if verifier_signal or verifier_source:
            if any(marker in low for marker in FATAL_BROWSER_MARKERS):
                return "FAIL", "verifier_infrastructure_error"
            if verifier_signal:
                pending = "REVIEW", "verifier_interaction_unverified"
    for key in ("observation", "verification", "verifier", "browser", "infrastructure"):
        nested = record.get(key)
        if isinstance(nested, dict):
            nested_source = source if key == "observation" else source + " " + key
            issue = error_issue(nested, action_type, nested_source)
            if issue and issue[0] == "FAIL":
                return issue
            pending = pending or issue
    return pending


def read_trace_issue(folder):
    tp = os.path.join(folder, "trace.jsonl")
    if not os.path.exists(tp):
        return None
    pending = None
    try:
        with open(tp, encoding="utf-8-sig") as fh:
            for line_number, line in enumerate(fh, 1):
                if not line.strip():
                    continue
                try:
                    record = json.loads(line)
                except (ValueError, UnicodeError):
                    pending = pending or ("REVIEW", f"trace_invalid_json:line{line_number}")
                    continue
                issue = error_issue(record)
                if issue and issue[0] == "FAIL":
                    return issue[0], f"trace:{issue[1]}:line{line_number}"
                if issue:
                    pending = pending or (issue[0], f"trace:{issue[1]}:line{line_number}")
    except (OSError, UnicodeError):
        return "REVIEW", "trace_unreadable"
    return pending


def has_real_evidence(rep, folder):
    """Require an explicit boolean verification and a real nonempty artifact.

    Report formats without this explicit proof remain REVIEW; this function
    never fabricates a verified flag from reflection or a screenshot name.
    """
    verification = rep.get("verification")
    verification = verification if isinstance(verification, dict) else {}
    verified = rep.get("verified", verification.get("verified"))
    if verified is not True:
        return False, "verification_not_boolean_true"
    shot = (rep.get("screenshot") or rep.get("screenshot_path")
            or verification.get("screenshot") or verification.get("screenshot_path"))
    if not isinstance(shot, str) or not shot.strip():
        return False, "screenshot_missing_or_invalid_path"
    candidates = [shot] if os.path.isabs(shot) else [os.path.join(folder, shot), shot]
    for candidate in candidates:
        try:
            if os.path.isfile(candidate) and os.path.getsize(candidate) > 0:
                return True, "evidence_ok"
        except OSError:
            continue
    return False, "screenshot_not_a_nonempty_file"


def env_check(rep, man):
    exp = man.get("expected_env", {})
    if not exp:
        return "ok", "no_expected_env"
    env = rep.get("env") if isinstance(rep.get("env"), dict) else {}
    present = {k: (env.get(k) if k in env else rep.get(k)) for k in exp}
    have = {k: v for k, v in present.items() if v not in (None, "")}
    if not have:
        return "review", "env_missing_provenance"
    for k, v in have.items():
        if str(v) != str(exp[k]):
            return "review", f"env_mismatch:{k}"
    # sebagian marker ada & cocok, sisanya hilang -> masih review (provenance tak lengkap)
    if len(have) < len(exp):
        return "review", "env_partial_provenance"
    return "ok", "env_ok"


def check_cell(folder, man):
    rid = os.path.basename(folder)
    meta = parse_rid(rid, man)
    rp = os.path.join(folder, "report.json")
    if meta is None:
        return rid, None, "FAIL", "rid_unparseable_vs_manifest", "rerun", ""
    # identitas run vs manifest
    if (meta["config"] not in man["_cfg"] or meta["scenario"] not in man["_scen"]
            or meta["seed"] not in man["_seed"] or meta["model"] != man["model"]):
        return rid, meta, "FAIL", "identity_not_in_manifest", "rerun", ""
    if not os.path.exists(rp):
        return rid, meta, "FAIL", "no_report_json", "rerun", ""
    try:
        with open(rp, "rb") as fh:
            raw = fh.read()
    except OSError:
        return rid, meta, "REVIEW", "report_unreadable", "review", ""
    h = hashlib.sha256(raw).hexdigest()[:16]
    try:
        rep = json.loads(raw.decode("utf-8"))
    except Exception as e:
        return rid, meta, "FAIL", f"json_parse_error:{type(e).__name__}", "rerun", h
    if not isinstance(rep, dict):
        return rid, meta, "FAIL", "schema_report_not_object", "rerun", h
    if not REQ.issubset(rep) or not isinstance(rep.get("success"), bool):
        return rid, meta, "FAIL", "schema_missing_required", "rerun", h
    if not is_finite_duration(rep.get("wall_clock_s")):
        return rid, meta, "FAIL", "wall_clock_not_finite", "rerun", h
    # Structured error classification (report + trace). Unclear provenance is
    # quarantined; an ordinary command failure is not a reason to rerun a cell.
    report_issue = error_issue(rep)
    trace_issue = read_trace_issue(folder)
    for issue in (report_issue, trace_issue):
        if issue and issue[0] == "FAIL":
            return rid, meta, "FAIL", issue[1], "rerun", h
    for issue in (report_issue, trace_issue):
        if issue:
            return rid, meta, "REVIEW", issue[1], "review", h
    # bukti untuk sel XSS yang mengaku sukses
    is_xss = any(fam in meta["scenario"].lower() for fam in man.get("xss_families", []))
    if is_xss and rep.get("success") is True:
        ok, why = has_real_evidence(rep, folder)
        if not ok:
            return rid, meta, "REVIEW", f"xss_success_unverified:{why}", "review", h
    # lingkungan
    st, why = env_check(rep, man)
    if st == "review":
        return rid, meta, "REVIEW", why, "review", h
    return rid, meta, "PASS", "ok", "reuse", h


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("--manifest", default=os.path.join(here, "k2b_manifest.json"))
    ap.add_argument("--runs", default="runs")
    args = ap.parse_args()
    man = load_manifest(args.manifest)
    os.makedirs("results", exist_ok=True)

    # roster terjadwal dari MANIFEST
    expected = set()
    for c in man["configs"]:
        for s in man["scenarios"]:
            for sd in man["seeds"]:
                expected.add(f"k2b-{c}-{man['model']}-{s}-s{sd}")

    rows, present = [], set()
    counts = {"reuse": 0, "rerun": 0, "review": 0}
    for folder in sorted(glob.glob(os.path.join(args.runs, "k2b-*"))):
        rid, meta, status, reason, decision, h = check_cell(folder, man)
        counts[decision] = counts.get(decision, 0) + 1
        present.add(rid)
        rows.append({"rid": rid, "config": meta["config"] if meta else "?",
                     "model": meta["model"] if meta else "?",
                     "scenario": meta["scenario"] if meta else "?",
                     "seed": meta["seed"] if meta else "?",
                     "status": status, "reason": reason,
                     "decision": decision, "report_sha16": h})
    missing = sorted(expected - present)
    unknown = sorted(present - expected)          # folder di luar roster beku
    with open("results/k2b_integrity_report.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["rid", "config", "model", "scenario", "seed",
                                           "status", "reason", "decision", "report_sha16"])
        w.writeheader(); w.writerows(rows)
    summary = {
        "manifest_total_scheduled": man["expected_total"],
        "cells_on_disk": len(rows),
        "reuse": counts.get("reuse", 0),
        "rerun_integrity_fail": counts.get("rerun", 0),
        "review_quarantine": counts.get("review", 0),
        "missing_not_yet_run": len(missing),
        "missing_examples": missing[:10],
        "unknown_outside_roster": len(unknown),
        "unknown_examples": unknown[:10],
        "policy": "manifest roster; PASS->reuse, FAIL->rerun, REVIEW->quarantine; "
                  "missing provenance/evidence is REVIEW not silent reuse; "
                  "rerun hanya sel gagal, bukan seluruh 468.",
    }
    json.dump(summary, open("results/k2b_integrity_summary.json", "w", encoding="utf-8"), indent=2)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
